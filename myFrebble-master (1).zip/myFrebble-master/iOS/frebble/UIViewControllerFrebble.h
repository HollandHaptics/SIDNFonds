//
//  UIViewControllerDismissKeyboard
//  frebble
//
//  Created by S. Mooij on 11/03/15.
//  Copyright (c) 2015 HollandHaptics. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Connection.h"
#import "Frebble.h"

@interface UIViewControllerFrebble : UIViewController <ConnectionDelegate>

@end