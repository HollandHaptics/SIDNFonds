# myFrebble
myFrebble mobile apps

Contains:
- myFrebble app for Android
- myFrebble app for iOS
- myFrebble server software