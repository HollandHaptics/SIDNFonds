package com.hollandhaptics.frebble;

import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothGatt;
import android.bluetooth.BluetoothGattCharacteristic;
import android.bluetooth.BluetoothGattService;
import android.bluetooth.BluetoothManager;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.GamesActivityResultCodes;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.Player;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.Multiplayer;
import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;
import com.google.android.gms.games.multiplayer.Participant;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessage;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessageReceivedListener;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomConfig;
import com.google.android.gms.games.multiplayer.realtime.RoomStatusUpdateListener;
import com.google.android.gms.games.multiplayer.realtime.RoomUpdateListener;
import com.google.android.gms.plus.Plus;

import com.google.example.games.basegameutils.BaseGameUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity implements
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        View.OnClickListener,
        RealTimeMessageReceivedListener,
        RoomStatusUpdateListener,
        RoomUpdateListener,
        OnInvitationReceivedListener {

    // tag for debug logging
    final static String TAG = "MyFrebble";
    private static final int REQUEST_ENABLE_BT = 1;
    // Request codes for the UIs that we show with startActivityForResult:
    final static int RC_SELECT_PLAYERS = 10000;
    final static int RC_INVITATION_INBOX = 10001;
    final static int RC_WAITING_ROOM = 10002;
    // request codes we use when invoking an external activity
    private static final int RC_RESOLVE = 5000;
    private static final int RC_UNUSED = 5001;
    private static final int RC_SIGN_IN = 9001;
    // Stops scanning after 5 seconds.
    private static final long SCAN_PERIOD = 5000;

    private BluetoothAdapter mBluetoothAdapter;
    private boolean mScanning;
    private boolean mConnected;
    private Handler mHandler;
    private ArrayList<BluetoothDevice> mLeDevices;
    private ArrayList<Integer> mRSSI;
    private String mDeviceAddress;
    private BluetoothLeService mBluetoothLeService;
    private BluetoothGatt mBluetoothGatt;
    private BluetoothGattCharacteristic mNotifyCharacteristic;
    private BluetoothGattCharacteristic mWriteCharacteristic;
    // Code to manage Service lifecycle.
    private final ServiceConnection mServiceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName componentName, IBinder service) {
            mBluetoothLeService = ((BluetoothLeService.LocalBinder) service).getService();
            if (!mBluetoothLeService.initialize()) {
                Log.e(TAG, "Unable to initialize Bluetooth");
                finish();
            }
            // Automatically connects to the device upon successful start-up initialization.
            mBluetoothLeService.connect(mDeviceAddress);
        }
        @Override
        public void onServiceDisconnected(ComponentName componentName) {
            mBluetoothLeService = null;
        }
    };

    // Client used to interact with Google APIs
    private GoogleApiClient mGoogleApiClient;
    // Are we currently resolving a connection failure?
    private boolean mResolvingConnectionFailure = false;
    // Has the user clicked the sign-in button?
    private boolean mSignInClicked = false;
    // Automatically start the sign-in flow when the Activity starts
    private boolean mAutoStartSignInFlow = false;
    // Room ID where the currently active game is taking place; null if we're
    // not playing.
    String mRoomId = null;
    // The participants in the currently active game
    ArrayList<Participant> mParticipants = null;
    // My participant ID in the currently active game
    String mMyId = null;
    // If non-null, this is the id of the invitation we received via the
    // invitation listener
    String mIncomingInvitationId = null;
    // Message buffer for sending messages
    byte[] mMsgBuf = new byte[2];
    // Current state of the game:
    int mScore = 0; // user's current score
    // Score of other participants. We update this as we receive their scores
    // from the network.
    Map<String, Integer> mParticipantScore = new HashMap<String, Integer>();
    // Participants who sent us their final score.
    Set<String> mFinishedParticipants = new HashSet<String>();
    // This array lists everything that's clickable, so we can install click
    // event handlers.
    final static int[] CLICKABLES = {
            R.id.button_accept_popup_invitation,
            R.id.button_decline_popup_invitation,
            R.id.button_connect_frebble,
            R.id.button_connect_frebble2,
            R.id.button_invite_players,
            R.id.button_see_invitations,
            R.id.button_sign_in,
            R.id.button_sign_out,
            R.id.button_end_game
    };
    // This array lists all the individual screens our game has.
    final static int[] SCREENS = {
            R.id.screen_game,
            R.id.screen_main,
            R.id.screen_sign_in,
            R.id.screen_wait//,
            //R.id.screen_le_device_scan
    };
    int mCurScreen = -1;

    /**
     * onCreate                     Called when the Activity is created.
     * @param savedInstanceState    The active instance Bundle
     */
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mHandler = new Handler();
        // Use this check to determine whether BLE is supported on the device.  Then you can
        // selectively disable BLE-related features.
        if (!getPackageManager().hasSystemFeature(PackageManager.FEATURE_BLUETOOTH_LE)) {
            showToast(R.string.ble_not_supported);
            finish();
        }
        // Initializes a Bluetooth adapter.  For API level 18 and above, get a reference to
        // BluetoothAdapter through BluetoothManager.
        final BluetoothManager bluetoothManager =
                (BluetoothManager) getSystemService(Context.BLUETOOTH_SERVICE);
        mBluetoothAdapter = bluetoothManager.getAdapter();
        // Checks if Bluetooth is supported on the device.
        if (mBluetoothAdapter == null) {
            showToast(R.string.error_bluetooth_not_supported);
            finish();
            return;
        }
        // Create the Google Api Client with access to the Play Game services
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(Plus.API).addScope(Plus.SCOPE_PLUS_LOGIN)
                .addApi(Games.API).addScope(Games.SCOPE_GAMES)
                // add other APIs and scopes here as needed
                .build();
        // set up a click listener for everything we care about
        for(int id : CLICKABLES) {
            findViewById(id).setOnClickListener(this);
        }
    }

    /**
     * onResume
     * Called when the Activity is resumed.
     */
    @Override
    protected void onResume() {
        super.onResume();
        Log.d(TAG, "onResume(): resuming activity");
        if(mCurScreen == R.id.screen_wait) {
            switchToMainScreen();
        }
    }

    /**
     * onClick      Handles click events
     * @param v     The active View
     */
    @Override
    public void onClick(View v) {
        Intent intent;

        switch(v.getId()) {
            case R.id.button_sign_in:
                // user wants to sign in
                // start the sign-in flow
                Log.d(TAG, "Sign-in button clicked");
                mSignInClicked = true;
                mGoogleApiClient.connect();
            break;
            case R.id.button_sign_out:
                // user wants to sign out
                // sign out.
                Log.d(TAG, "Sign-out button clicked");
                mSignInClicked = false;
                Games.signOut(mGoogleApiClient);
                mGoogleApiClient.disconnect();
                switchToScreen(R.id.screen_sign_in);
            break;
            case R.id.button_connect_frebble:
            case R.id.button_connect_frebble2:
                // TODO
                if (mScanning == true) {
                    scanLeDevice(false);
                } else {
                    if(mDeviceAddress != null) {
                    //if(mLeDevices != null && !mLeDevices.isEmpty()) {
                        if(mConnected == true) {
                            mBluetoothLeService.disconnect();
                        } else {
                            mBluetoothLeService.connect(mDeviceAddress);
                        }
                    } else {
                        scanLeDevice(true);
                    }
                }
            break;
            case R.id.button_invite_players:
                // show list of invitable players
                intent = Games.RealTimeMultiplayer.getSelectOpponentsIntent(mGoogleApiClient, 1, 1);
                switchToScreen(R.id.screen_wait);
                startActivityForResult(intent, RC_SELECT_PLAYERS);
            break;
            case R.id.button_see_invitations:
                // show list of pending invitations
                intent = Games.Invitations.getInvitationInboxIntent(mGoogleApiClient);
                switchToScreen(R.id.screen_wait);
                startActivityForResult(intent, RC_INVITATION_INBOX);
            break;
            case R.id.button_accept_popup_invitation:
                // user wants to accept the invitation shown on the invitation popup
                // (the one we got through the OnInvitationReceivedListener).
                acceptInviteToRoom(mIncomingInvitationId);
                mIncomingInvitationId = null;
            break;
            case R.id.button_decline_popup_invitation:
                // user wants to decline the invitation shown on the invitation popup
                // (the one we got through the OnInvitationReceivedListener).
                declineInviteToRoom(mIncomingInvitationId);
                // TODO
                mIncomingInvitationId = null;
            break;
            case R.id.button_end_game:
                leaveRoom();
            break;
        }
    }

    /**
     *
     * @param requestCode
     * @param resultCode
     * @param intent
     */
    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        switch (requestCode) {
            case REQUEST_ENABLE_BT:
                // User chose not to enable Bluetooth.
                if(resultCode == Activity.RESULT_CANCELED) {
                    finish();
                    return;
                }
                break;
            case RC_SELECT_PLAYERS:
                // we got the result from the "select players" UI -- ready to create the room
                handleSelectPlayersResult(resultCode, intent);
                break;
            case RC_INVITATION_INBOX:
                // we got the result from the "select invitation" UI (invitation inbox). We're
                // ready to accept the selected invitation:
                handleInvitationInboxResult(resultCode, intent);
                break;
            case RC_WAITING_ROOM:
                // we got the result from the "waiting room" UI.
                if (resultCode == Activity.RESULT_OK) {
                    // ready to start playing
                    Log.d(TAG, "Starting game (waiting room returned OK).");
                    startGame();
                } else if (resultCode == GamesActivityResultCodes.RESULT_LEFT_ROOM) {
                    // player indicated that they want to leave the room
                    leaveRoom();
                } else if (resultCode == Activity.RESULT_CANCELED) {
                    // Dialog was cancelled (user pressed back key, for instance). In our game,
                    // this means leaving the room too. In more elaborate games, this could mean
                    // something else (like minimizing the waiting room UI).
                    leaveRoom();
                }
                break;
            case RC_SIGN_IN:
                Log.d(TAG, "onActivityResult with requestCode == RC_SIGN_IN, responseCode="
                        + resultCode + ", intent=" + intent);
                mSignInClicked = false;
                mResolvingConnectionFailure = false;
                if (resultCode == RESULT_OK) {
                    mGoogleApiClient.connect();
                } else {
                    BaseGameUtils.showActivityResultError(this,requestCode,resultCode, R.string.signin_other_error);
                }
                break;
        }
    }

    /**
     *
     * @param enable
     */
    private void scanLeDevice(final boolean enable) {
        if (enable) {
            // Stops scanning after a pre-defined scan period.
            mHandler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    if(mScanning) {
                        mScanning = false;
                        mBluetoothAdapter.stopLeScan(mLeScanCallback);
                        if(!mLeDevices.isEmpty()) {
                            mDeviceAddress = mLeDevices.get(getIndexOfHighestRSSI()).getAddress();
                            //mBluetoothLeService.connect(mDeviceAddress);
                            registerReceiver(mGattUpdateReceiver, makeGattUpdateIntentFilter());
                            if (mBluetoothLeService != null) {
                                showToast(R.string.frebble_connecting);
                                final boolean result = mBluetoothLeService.connect(mDeviceAddress);
                                Log.d(TAG, "Connect request result=" + result);
                            }
                        } else {
                            updateBLEButton(R.string.connect_frebble);
                            showToast(R.string.no_frebble_found);
                        }
                    }
                }
            }, SCAN_PERIOD);

            showToast(R.string.ble_start_scan);
            updateBLEButton(R.string.cancel_frebble);
            mLeDevices = new ArrayList<BluetoothDevice>();
            mRSSI = new ArrayList<Integer>();
            mScanning = true;
            //final UUID[] frebble_services = new UUID[]{
            //    UUID.fromString("00001800-0000-1000-8000-00805f9b34fb"), // Generic Access
            //    UUID.fromString("00001801-0000-1000-8000-00805f9b34fb"), // Generic Attribute
            //    UUID.fromString("6e400001-b5a3-f393-e0a9-e50e24dcca9e"), // Nordic UART Service
            //    UUID.fromString("0000180a-0000-1000-8000-00805f9b34fb") // Device Information
            //};
            //mBluetoothAdapter.startLeScan(frebble_services, mLeScanCallback);
            mBluetoothAdapter.startLeScan(mLeScanCallback);

            //try {
                 //List<ScanFilter> filters, ScanSettings settings, ScanCallback callback
                //TODO
                // http://developer.radiusnetworks.com/2014/10/28/android-5.0-scanning.html
                //BluetoothLeScanner scanner = getBluetoothAdapter().getBluetoothLeScanner();
                //ScanSettings settings = new ScanSettings.Builder()
                //        .setScanMode(ScanSettings.SCAN_MODE_LOW_POWER)
                //        .build();
                //List<ScanFilter> filters = new ArrayList<ScanFilter>();
                //scanner.startScan(filters, settings, myCallbackMethod);
                //

                //mBluetoothAdapter.getBluetoothLeScanner().startScan(mLeScanCallback);
            //} catch(IllegalArgumentException e) {
                //
            //}
        } else {
            mScanning = false;
            mBluetoothAdapter.stopLeScan(mLeScanCallback);
            updateBLEButton(R.string.connect_frebble);
        }
    }

    // Handles various events fired by the Service.
    // ACTION_GATT_CONNECTED: connected to a GATT server.
    // ACTION_GATT_DISCONNECTED: disconnected from a GATT server.
    // ACTION_GATT_SERVICES_DISCOVERED: discovered GATT services.
    // ACTION_DATA_AVAILABLE: received data from the device.  This can be a result of read
    //                        or notification operations.
    /**
     *
     */
    private final BroadcastReceiver mGattUpdateReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            final String action = intent.getAction();
            if (BluetoothLeService.ACTION_GATT_CONNECTED.equals(action)) {
                mConnected = true;
                updateBLEButton(R.string.disconnect_frebble);
                showToast(R.string.frebble_connected);
                Log.d(TAG, "ACTION_GATT_CONNECTED");
                //updateConnectionState(R.string.connected);
                //invalidateOptionsMenu();
            } else if (BluetoothLeService.ACTION_GATT_DISCONNECTED.equals(action)) {
                mConnected = false;
                // TODO
                mDeviceAddress = null;
                updateBLEButton(R.string.connect_frebble);
                Log.d(TAG, "ACTION_GATT_DISCONNECTED");
                //updateConnectionState(R.string.disconnected);
                //invalidateOptionsMenu();
                //clearUI();
            } else if (BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED.equals(action)) {
                Log.d(TAG, "ACTION_GATT_SERVICES_DISCOVERED");
                List<BluetoothGattService> gattServices = mBluetoothLeService.getSupportedGattServices();
                for (BluetoothGattService gattService : gattServices) {
                    if(gattService.getUuid().toString().equalsIgnoreCase("6e400001-b5a3-f393-e0a9-e50e24dcca9e")) {
                        final BluetoothGattCharacteristic gattCharacteristicTX = gattService.getCharacteristic(UUID.fromString("6e400002-b5a3-f393-e0a9-e50e24dcca9e"));
                        final int charaPropTX = gattCharacteristicTX.getProperties();
                        if ((charaPropTX | BluetoothGattCharacteristic.PROPERTY_WRITE) > 0) {
                            mWriteCharacteristic = gattCharacteristicTX;
                        }
                        final BluetoothGattCharacteristic gattCharacteristicRX = gattService.getCharacteristic(UUID.fromString("6e400003-b5a3-f393-e0a9-e50e24dcca9e"));
                        final int charaPropRX = gattCharacteristicRX.getProperties();
                        if ((charaPropRX | BluetoothGattCharacteristic.PROPERTY_NOTIFY) > 0) {
                            mNotifyCharacteristic = gattCharacteristicRX;
                            mBluetoothLeService.setCharacteristicNotification(
                                gattCharacteristicRX, true);
                        }
                    }
                }
                // Show all the supported services and characteristics on the user interface.
                //displayGattServices(mBluetoothLeService.getSupportedGattServices());
            } else if (BluetoothLeService.ACTION_DATA_AVAILABLE.equals(action)) {
                //Log.d(TAG, "ACTION_DATA_AVAILABLE");
                //displayData(intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
                Log.d(TAG, intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
                broadcastForce(intent.getStringExtra(BluetoothLeService.EXTRA_DATA));
            }
        }
    };

    // Handle the result of the "Select players UI" we launched when the user clicked the
    // "Invite friends" button. We react by creating a room with those players.

    /**
     *
     * @param response
     * @param data
     */
    private void handleSelectPlayersResult(int response, Intent data) {
        if (response != Activity.RESULT_OK) {
            Log.w(TAG, "*** select players UI cancelled, " + response);
            switchToMainScreen();
            return;
        }

        Log.d(TAG, "Select players UI succeeded.");

        // get the invitee list
        final ArrayList<String> invitees = data.getStringArrayListExtra(Games.EXTRA_PLAYER_IDS);
        Log.d(TAG, "Invitee count: " + invitees.size());

        // get the automatch criteria
        Bundle autoMatchCriteria = null;
        int minAutoMatchPlayers = 0;//data.getIntExtra(Multiplayer.EXTRA_MIN_AUTOMATCH_PLAYERS, 0);
        int maxAutoMatchPlayers = 0;//data.getIntExtra(Multiplayer.EXTRA_MAX_AUTOMATCH_PLAYERS, 0);
        if (minAutoMatchPlayers > 0 || maxAutoMatchPlayers > 0) {
            autoMatchCriteria = RoomConfig.createAutoMatchCriteria(
                    minAutoMatchPlayers, maxAutoMatchPlayers, 0);
            Log.d(TAG, "Automatch criteria: " + autoMatchCriteria);
        }

        // create the room
        Log.d(TAG, "Creating room...");
        RoomConfig.Builder rtmConfigBuilder = RoomConfig.builder(this);
        rtmConfigBuilder.addPlayersToInvite(invitees);
        rtmConfigBuilder.setMessageReceivedListener(this);
        rtmConfigBuilder.setRoomStatusUpdateListener(this);
        if (autoMatchCriteria != null) {
            rtmConfigBuilder.setAutoMatchCriteria(autoMatchCriteria);
        }
        switchToScreen(R.id.screen_wait);
        keepScreenOn();
        resetGameVars();
        Games.RealTimeMultiplayer.create(mGoogleApiClient, rtmConfigBuilder.build());
        Log.d(TAG, "Room created, waiting for it to be ready...");
    }

    // Handle the result of the invitation inbox UI, where the player can pick an invitation
    // to accept. We react by accepting the selected invitation, if any.

    /**
     *
     * @param response
     * @param data
     */
    private void handleInvitationInboxResult(int response, Intent data) {
        if (response != Activity.RESULT_OK) {
            Log.w(TAG, "*** invitation inbox UI cancelled, " + response);
            switchToMainScreen();
            return;
        }

        Log.d(TAG, "Invitation inbox UI succeeded.");
        Invitation inv = data.getExtras().getParcelable(Multiplayer.EXTRA_INVITATION);

        // accept invitation
        acceptInviteToRoom(inv.getInvitationId());
    }

    // Accept the given invitation.

    /**
     *
     * @param invId
     */
    private void acceptInviteToRoom(String invId) {
        // accept the invitation
        Log.d(TAG, "Accepting invitation: " + invId);
        RoomConfig.Builder roomConfigBuilder = RoomConfig.builder(this);
        roomConfigBuilder.setInvitationIdToAccept(invId)
                .setMessageReceivedListener(this)
                .setRoomStatusUpdateListener(this);
        switchToScreen(R.id.screen_wait);
        keepScreenOn();
        resetGameVars();
        Games.RealTimeMultiplayer.join(mGoogleApiClient, roomConfigBuilder.build());
    }

    // TODO
    // Decline the given invitation.

    /**
     *
     * @param invId
     */
    private void declineInviteToRoom(String invId) {
        // accept the invitation
        Log.d(TAG, "Declining invitation: " + invId);
        RoomConfig.Builder roomConfigBuilder = RoomConfig.builder(this);
        roomConfigBuilder.setInvitationIdToAccept(invId)
                .setMessageReceivedListener(this)
                .setRoomStatusUpdateListener(this);
        switchToScreen(R.id.screen_wait);
        keepScreenOn();
        resetGameVars();
        Games.RealTimeMultiplayer.join(mGoogleApiClient, roomConfigBuilder.build());
    }

    // Activity is going to the background. We have to leave the current room.

    /**
     *
     */
    @Override
    protected void onStop() {
        Log.d(TAG, "onStop(): disconnecting");

        // if we're in a room, leave it.
        leaveRoom();

        // stop trying to keep the screen on
        stopKeepingScreenOn();

        if (mGoogleApiClient == null || !mGoogleApiClient.isConnected()){
            switchToScreen(R.id.screen_sign_in);
        }
        else {
            //mGoogleApiClient.disconnect();
            switchToScreen(R.id.screen_wait);
        }
        super.onStop();
    }

    // Activity just got to the foreground. We switch to the wait screen because we will now
    // go through the sign-in flow (remember that, yes, every time the Activity comes back to the
    // foreground we go through the sign-in flow -- but if the user is already authenticated,
    // this flow simply succeeds and is imperceptible).

    /**
     *
     */
    @Override
    protected void onStart() {
        switchToScreen(R.id.screen_wait);
        if (mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            Log.w(TAG,
                    "GameHelper: client was already connected on onStart()");
        } else {
            Log.d(TAG,"Connecting client.");
            mGoogleApiClient.connect();
        }
        super.onStart();
    }

    // Handle back key to make sure we cleanly leave a game if we are in the middle of one

    /**
     *
     * @param keyCode
     * @param e
     * @return
     */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent e) {
        if (keyCode == KeyEvent.KEYCODE_BACK && mCurScreen == R.id.screen_game) {
            leaveRoom();
            return true;
        }
        return super.onKeyDown(keyCode, e);
    }

    // Leave the room.

    /**
     *
     */
    private void leaveRoom() {
        Log.d(TAG, "Leaving room.");
        stopKeepingScreenOn();
        if (mRoomId != null) {
            Games.RealTimeMultiplayer.leave(mGoogleApiClient, this, mRoomId);
            mRoomId = null;
            switchToScreen(R.id.screen_wait);
        } else {
            switchToMainScreen();
        }
    }

    // Show the waiting room UI to track the progress of other players as they enter the
    // room and get connected.

    /**
     *
     * @param room
     */
    private void showWaitingRoom(Room room) {
        // minimum number of players required for our game
        // For simplicity, we require everyone to join the game before we start it
        // (this is signaled by Integer.MAX_VALUE).
        //final int MIN_PLAYERS = Integer.MAX_VALUE;
        // at least 2 players required for our game
        final int MIN_PLAYERS = 2;

        Intent i = Games.RealTimeMultiplayer.getWaitingRoomIntent(mGoogleApiClient, room, MIN_PLAYERS);

        // show waiting room UI
        startActivityForResult(i, RC_WAITING_ROOM);
    }

    // Called when we get an invitation to play a game. We react by showing that to the user.

    /**
     *
     * @param invitation
     */
    @Override
    public void onInvitationReceived(Invitation invitation) {
        // We got an invitation to play a game! So, store it in
        // mIncomingInvitationId
        // and show the popup on the screen.
        mIncomingInvitationId = invitation.getInvitationId();
        ((TextView) findViewById(R.id.incoming_invitation_text)).setText(
                invitation.getInviter().getDisplayName() + "\n" +
                        getString(R.string.is_inviting_you));
        switchToScreen(mCurScreen); // This will show the invitation popup
    }

    /**
     *
     * @param invitationId
     */
    @Override
    public void onInvitationRemoved(String invitationId) {
        if (mIncomingInvitationId.equals(invitationId)) {
            mIncomingInvitationId = null;
            switchToScreen(mCurScreen); // This will hide the invitation popup
        }
    }

    /**
     *
     */
    private BluetoothAdapter.LeScanCallback mLeScanCallback =
            new BluetoothAdapter.LeScanCallback() {
        @Override
        public void onLeScan(final BluetoothDevice device, final int rssi, byte[] scanRecord) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    if (mScanning) {
                        if (mLeDevices != null && !mLeDevices.contains(device)) {
                            Log.d(TAG, "BLE device found: " + device.getName() + " (" + device.getAddress() + ")");
                            // Student demo Frebbles:
                            //if (device.getAddress().equalsIgnoreCase("F5:5F:AE:E4:55:69") | device.getAddress().equalsIgnoreCase("F3:D1:BD:72:44:4F")) {
                            // Development Frebbles:
                            //if(device != null) {
                                if (device.getName() == null || device.getName().equalsIgnoreCase("Frebble")) {
                                    Log.d(TAG, "Frebble found: " + device.getName() + " (" + device.getAddress() + ") RSSI:" + rssi);
                                    if(rssi > -80) {
                                        mRSSI.add(rssi);
                                        mLeDevices.add(device);
                                    }
                                }
                            //}
                        }
                    }
                }
            });
        }
    };

    /**
     *
     * @param bundle
     */
    @Override
    public void onConnected(Bundle bundle) {
        Log.d(TAG, "onConnected(): connected to Google APIs");
        Log.d(TAG, "Sign-in succeeded.");

        // Ensures Bluetooth is enabled on the device.  If Bluetooth is not currently enabled,
        // fire an intent to display a dialog asking the user to grant permission to enable it.
        if (!mBluetoothAdapter.isEnabled()) {
            if (!mBluetoothAdapter.isEnabled()) {
                Intent enableBtIntent = new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE);
                startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT);
            }
        }
        // Bind the BLE Service
        Intent gattServiceIntent = new Intent(this, BluetoothLeService.class);
        bindService(gattServiceIntent, mServiceConnection, BIND_AUTO_CREATE);

        // Set the greeting appropriately on main menu
        Player p = Games.Players.getCurrentPlayer(mGoogleApiClient);
        String displayName;
        if (p == null) {
            Log.w(TAG, "mGamesClient.getCurrentPlayer() is NULL!");
            displayName = "???";
        } else {
            displayName = p.getDisplayName();
        }

        // register listener so we are notified if we receive an invitation to play
        // while we are in the game
        Games.Invitations.registerInvitationListener(mGoogleApiClient, this);

        if(bundle != null) {
            Log.d(TAG, "onConnected: connection hint provided. Checking for invite.");
            Invitation inv = bundle
                    .getParcelable(Multiplayer.EXTRA_INVITATION);
            if(inv != null && inv.getInvitationId() != null) {
                // retrieve and cache the invitation ID
                Log.d(TAG, "onConnected: connection hint has a room invite!");
                acceptInviteToRoom(inv.getInvitationId());
                return;
            }
        }

        switchToMainScreen();
    }

    /**
     *
     * @param i
     */
    @Override
    public void onConnectionSuspended(int i) {
        Log.d(TAG, "onConnectionSuspended(): attempting to connect");
        mGoogleApiClient.connect();
    }

    /**
     *
     * @param connectionResult
     */
    @Override
    public void onConnectionFailed(ConnectionResult connectionResult) {
        Log.d(TAG, "onConnectionFailed(): attempting to resolve");
        if (mResolvingConnectionFailure) {
            Log.d(TAG, "onConnectionFailed(): already resolving");
            return;
        }

        if (mSignInClicked || mAutoStartSignInFlow) {
            mAutoStartSignInFlow = false;
            mSignInClicked = false;
            mResolvingConnectionFailure = true;
            if (!BaseGameUtils.resolveConnectionFailure(this, mGoogleApiClient, connectionResult,
                    RC_SIGN_IN, getString(R.string.signin_other_error))) {
                mResolvingConnectionFailure = false;
            }
        }

        switchToScreen(R.id.screen_sign_in);
    }

    // Called when we are connected to the room. We're not ready to play yet! (maybe not everybody
    // is connected yet).

    /**
     *
     * @param room
     */
    @Override
    public void onConnectedToRoom(Room room) {
        Log.d(TAG, "onConnectedToRoom.");

        // get room ID, participants and my ID:
        mRoomId = room.getRoomId();
        mParticipants = room.getParticipants();
        mMyId = room.getParticipantId(Games.Players.getCurrentPlayerId(mGoogleApiClient));

        // print out the list of participants (for debug purposes)
        Log.d(TAG, "Room ID: " + mRoomId);
        Log.d(TAG, "My ID " + mMyId);
        Log.d(TAG, "<< CONNECTED TO ROOM>>");
    }

    // Called when we've successfully left the room (this happens a result of voluntarily leaving
    // via a call to leaveRoom(). If we get disconnected, we get onDisconnectedFromRoom()).

    /**
     *
     * @param statusCode
     * @param roomId
     */
    @Override
    public void onLeftRoom(int statusCode, String roomId) {
        // we have left the room; return to main screen.
        Log.d(TAG, "onLeftRoom, code " + statusCode);
        switchToMainScreen();
    }

    // Called when we get disconnected from the room. We return to the main screen.

    /**
     *
     * @param room
     */
    @Override
    public void onDisconnectedFromRoom(Room room) {
        mRoomId = null;
        showGameError();
    }

    // Show error message about game being cancelled and return to main screen.

    /**
     *
     */
    private void showGameError() {
        BaseGameUtils.makeSimpleDialog(this, getString(R.string.game_problem));
        switchToMainScreen();
    }

    // Called when room has been created

    /**
     *
     * @param statusCode
     * @param room
     */
    @Override
    public void onRoomCreated(int statusCode, Room room) {
        Log.d(TAG, "onRoomCreated(" + statusCode + ", " + room + ")");
        if (statusCode != GamesStatusCodes.STATUS_OK) {
            Log.e(TAG, "*** Error: onRoomCreated, status " + statusCode);
            showGameError();
            return;
        }
        // show the waiting room UI
        showWaitingRoom(room);
    }

    // Called when room is fully connected.

    /**
     *
     * @param statusCode
     * @param room
     */
    @Override
    public void onRoomConnected(int statusCode, Room room) {
        Log.d(TAG, "onRoomConnected(" + statusCode + ", " + room + ")");
        if (statusCode != GamesStatusCodes.STATUS_OK) {
            Log.e(TAG, "*** Error: onRoomConnected, status " + statusCode);
            showGameError();
            return;
        }
        updateRoom(room);
    }

    /**
     *
     * @param statusCode
     * @param room
     */
    @Override
    public void onJoinedRoom(int statusCode, Room room) {
        Log.d(TAG, "onJoinedRoom(" + statusCode + ", " + room + ")");
        if (statusCode != GamesStatusCodes.STATUS_OK) {
            Log.e(TAG, "*** Error: onRoomConnected, status " + statusCode);
            showGameError();
            return;
        }
        // show the waiting room UI
        showWaitingRoom(room);
    }

    // We treat most of the room update callbacks in the same way: we update our list of
    // participants and update the display. In a real game we would also have to check if that
    // change requires some action like removing the corresponding player avatar from the screen,
    // etc.

    /**
     *
     * @param room
     * @param arg1
     */
    @Override
    public void onPeerDeclined(Room room, List<String> arg1) {
        updateRoom(room);
    }

    /**
     *
     * @param room
     * @param arg1
     */
    @Override
    public void onPeerInvitedToRoom(Room room, List<String> arg1) {
        updateRoom(room);
    }

    /**
     *
     * @param participant
     */
    @Override
    public void onP2PDisconnected(String participant) {
    }

    /**
     *
     * @param participant
     */
    @Override
    public void onP2PConnected(String participant) {
    }

    /**
     *
     * @param room
     * @param arg1
     */
    @Override
    public void onPeerJoined(Room room, List<String> arg1) {
        updateRoom(room);
    }

    /**
     *
     * @param room
     * @param peersWhoLeft
     */
    @Override
    public void onPeerLeft(Room room, List<String> peersWhoLeft) {
        updateRoom(room);
    }

    /**
     *
     * @param room
     */
    @Override
    public void onRoomAutoMatching(Room room) {
        updateRoom(room);
    }

    /**
     *
     * @param room
     */
    @Override
    public void onRoomConnecting(Room room) {
        updateRoom(room);
    }

    /**
     *
     * @param room
     * @param peers
     */
    @Override
    public void onPeersConnected(Room room, List<String> peers) {
        updateRoom(room);
    }

    /**
     *
     * @param room
     * @param peers
     */
    @Override
    public void onPeersDisconnected(Room room, List<String> peers) {
        updateRoom(room);
        for(String peer : peers) {
            showToast(peer + " ended the call.");
        }
    }

    /**
     *
     * @param room
     */
    private void updateRoom(Room room) {
        if (room != null) {
            mParticipants = room.getParticipants();
        }
        if (mParticipants != null) {
            //TODO updatePeerScoresDisplay();
        }
    }

    /**
     * GAME LOGIC SECTION. Methods that implement the game's rules.
     */

    // Reset game variables in preparation for a new game.

    /**
     *
     */
    private void resetGameVars() {
        mScore = 0;
        mParticipantScore.clear();
        mFinishedParticipants.clear();
    }

    // Start the gameplay phase of the game.

    /**
     *
     */
    private void startGame() {
        // TODO
        switchToScreen(R.id.screen_game);

        findViewById(R.id.button_end_game).setVisibility(View.VISIBLE);

        // run the gameTick() method every second to update the game.

    }

    /**
     * COMMUNICATIONS SECTION. Methods that implement the game's network
     * protocol.
     */

    // Called when we receive a real-time message from the network.
    // Messages in our game are made up of 2 bytes: the first one is 'F' or 'U'
    // indicating
    // whether it's a final or interim score. The second byte is the score.
    // There is also the
    // 'S' message, which indicates that the game should start.

    /**
     *
     * @param rtm
     */
    @Override
    public void onRealTimeMessageReceived(RealTimeMessage rtm) {
        byte[] buf = rtm.getMessageData();
        String sender = rtm.getSenderParticipantId();
        String str = new String(buf);
        Log.d(TAG, "Message received: " + str);
        if(mConnected) {
            Log.d(TAG, "Sending to Frebble: " + str);
            mBluetoothLeService.writeCharacteristic(mWriteCharacteristic, str);
            //mWriteCharacteristic.setValue(new Integer(str), BluetoothGattCharacteristic.FORMAT_UINT8, 0);
        }
    }

    // Broadcast my score to everybody else.

    /**
     *
     * @param force
     */
    private void broadcastForce(String force) {
        mMsgBuf = force.getBytes();
        // First byte in message indicates whether it's a final score or not
        //mMsgBuf[0] = (byte) (finalScore ? 'F' : 'U');
        // Second byte is the score.
        //mMsgBuf[1] = (byte) force;

        if(mParticipants != null && !mParticipants.isEmpty()) {
            // Send to every other participant.
            for (Participant p : mParticipants) {
                if (p.getParticipantId().equals(mMyId))
                    continue;
                if (p.getStatus() != Participant.STATUS_JOINED)
                    continue;
                //Games.RealTimeMultiplayer.sendReliableMessage(mGoogleApiClient, null, mMsgBuf,
                //        mRoomId, p.getParticipantId());
                Games.RealTimeMultiplayer.sendUnreliableMessage(mGoogleApiClient, mMsgBuf, mRoomId,
                            p.getParticipantId());
            }
        }
    }

    /**
     * UI SECTION. Methods that implement the game's UI.
     */


    /**
     *
     * @param screenId
     */
    private void switchToScreen(int screenId) {
        // make the requested screen visible; hide all others.
        for(int id : SCREENS) {
            findViewById(id).setVisibility(screenId == id ? View.VISIBLE : View.GONE);
        }
        mCurScreen = screenId;

        // should we show the invitation popup?
        boolean showInvPopup;
        if(mIncomingInvitationId == null) {
            // no invitation, so no popup
            showInvPopup = false;
        } else {
            // only show invitation on main screen
            showInvPopup = (mCurScreen == R.id.screen_main);
            // show on main screen and gameplay screen
            //showInvPopup = (mCurScreen == R.id.screen_main || mCurScreen == R.id.screen_game);
        }
        findViewById(R.id.invitation_popup).setVisibility(showInvPopup ? View.VISIBLE : View.GONE);
    }

    /**
     *
     */
    private void switchToMainScreen() {
        if(mGoogleApiClient != null && mGoogleApiClient.isConnected()) {
            switchToScreen(R.id.screen_main);
        }
        else {
            switchToScreen(R.id.screen_sign_in);
        }
    }

    // formats a score as a three-digit number
    String formatScore(int i) {
        if(i < 0)
            i = 0;
        String s = String.valueOf(i);
        return s.length() == 1 ? "00" + s : s.length() == 2 ? "0" + s : s;
    }

    /**
     * MISC SECTION. Miscellaneous methods.
     */

    // Sets the flag to keep this screen on. It's recommended to do that during
    // the
    // handshake when setting up a game, because if the screen turns off, the
    // game will be
    // cancelled.

    /**
     *
     */
    private void keepScreenOn() {
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    // Clears the flag that keeps the screen on.

    /**
     *
     */
    private void stopKeepingScreenOn() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    /**
     *
     * @param s
     */
    private void showToast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_LONG).show();
    }

    /**
     *
     * @param i
     */
    private void showToast(int i) {
        Toast.makeText(this, i, Toast.LENGTH_LONG).show();
    }

    /**
     * LOGIN
     */

    /**
     *
     * @return
     */
    private boolean isSignedIn() {
        return (mGoogleApiClient != null && mGoogleApiClient.isConnected());
    }

    /**
     *
     * @param i
     */
    private void updateBLEButton(int i) {
        //if (getActivity() == null) return;
        Button b = (Button) findViewById(R.id.button_connect_frebble);
        if (b != null) b.setText(i);
        Button b2 = (Button) findViewById(R.id.button_connect_frebble2);
        if (b2 != null) b2.setText(i);
    }

    /**
     *
     * @return
     */
    private static IntentFilter makeGattUpdateIntentFilter() {
        final IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_CONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_DISCONNECTED);
        intentFilter.addAction(BluetoothLeService.ACTION_GATT_SERVICES_DISCOVERED);
        intentFilter.addAction(BluetoothLeService.ACTION_DATA_AVAILABLE);
        return intentFilter;
    }

    /**
     *
     * @return
     */
    private int getIndexOfHighestRSSI() {
        int index = -1;
        int rssi = -120;
        for (int i : mRSSI) {
            if(i > rssi) {
                rssi = i;
                index = mRSSI.indexOf(i);
            }
        }
        return index;
    }
}
