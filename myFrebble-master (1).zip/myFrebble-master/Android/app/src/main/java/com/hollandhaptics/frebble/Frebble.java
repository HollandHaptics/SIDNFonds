package com.hollandhaptics.frebble;

public class Frebble {

    private String device_name;
    private String device_address;
    private String manufacturer_name;
    private String model_number;
    private String serial_number;
    private String hardware_revision;
    private String firmware_revision;
    private String software_revision;

    public Frebble(String device_name, String device_address, String manufacturer_name,
                   String model_number, String serial_number, String hardware_revision,
                   String firmware_revision, String software_revision) {
        setDeviceName(device_name);
        setDeviceAddress(device_address);
        setManufacturerName(manufacturer_name);
        setModelNumber(model_number);
        setSerialNumber(serial_number);
        setHardwareRevision(hardware_revision);
        setFirmwareRevision(firmware_revision);
        setSoftwareRevision(software_revision);
    }

    private void setDeviceName(String device_name) {
        this.device_name = device_name;
    }

    private void setDeviceAddress(String device_address) {
        this.device_address = device_address;
    }

    private void setManufacturerName(String manufacturer_name) {
        this.manufacturer_name = manufacturer_name;
    }

    private void setModelNumber(String model_number) {
        this.model_number = model_number;
    }

    private void setSerialNumber(String serial_number) {
        this.serial_number = serial_number;
    }

    private void setHardwareRevision(String hardware_revision) {
        this.hardware_revision = hardware_revision;
    }

    private void setFirmwareRevision(String firmware_revision) {
        this.firmware_revision = firmware_revision;
    }

    private void setSoftwareRevision(String software_revision) {
        this.software_revision = software_revision;
    }

    public String getDeviceName() {
        return device_name;
    }

    public String getDeviceAddress() {
        return device_address;
    }

    public String getManufacturerName() {
        return manufacturer_name;
    }

    public String getModelNumber() {
        return model_number;
    }

    public String getSerialNumber() {
        return serial_number;
    }

    public String getHardwareRevision() {
        return hardware_revision;
    }

    public String getFirmwareRevision() {
        return firmware_revision;
    }

    public String getSoftwareRevision() {
        return software_revision;
    }
}
