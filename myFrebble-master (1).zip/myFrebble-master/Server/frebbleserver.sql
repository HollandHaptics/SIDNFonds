CREATE TABLE t_user
(
	name		VARCHAR(32),
	email		VARCHAR(64) NOT NULL,
	passwordhash	VARCHAR(256) NOT NULL,
	passwordsalt	VARCHAR(256) NOT NULL,
	PRIMARY KEY (name),
	UNIQUE (email)
);
