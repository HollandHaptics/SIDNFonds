# myFrebble (Server)
myFrebble server software


IPv4-adres: 92.222.0.107

URL: ios.hollandhaptics.com

Gebruikersnaam: root

Wachtwoord: ob3KMXv2


To login use any SSH-client (f.e.: PuTTY - http://www.putty.org/).


To start the server run: cd /frebbleserver && screen -h 1024 -dmS frebbleserver java -cp bin/:lib/* com.hollandhaptics.frebble.server.FrebbleServer

To return to the screen if a server is already running run: screen -r
