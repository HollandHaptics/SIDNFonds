package com.hollandhaptics.frebble.server;
@SuppressWarnings("serial")
public class ExceptionProtocol extends Exception
{
}