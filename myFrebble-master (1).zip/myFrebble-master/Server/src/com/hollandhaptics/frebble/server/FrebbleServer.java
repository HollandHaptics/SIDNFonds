package com.hollandhaptics.frebble.server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;
import java.util.TreeMap;

import org.postgresql.util.Base64;

public class FrebbleServer
{
	private Map<String, User> users_;
	private Map<String, String> email2username_;

	public FrebbleServer()
	{
		users_ = new TreeMap<String, User>();
		email2username_ = new TreeMap<String, String>();
	}

	public Map<String, User> getUsers()
	{
		return users_;
	}

	public Map<String, String> getEmail2username()
	{
		return email2username_;
	}

	public static ResultSet getUser(Connection connection, String usernameOrEmail) throws SQLException
	{
		PreparedStatement preparedStatement;
		if (usernameOrEmail.contains("@"))
		{
			preparedStatement = connection.prepareStatement("SELECT name, email, passwordHash, passwordsalt FROM t_user WHERE email = ?;");
		}
		else
		{
			preparedStatement = connection.prepareStatement("SELECT name, email, passwordhash, passwordsalt FROM t_user WHERE name = ?;");
		}
		preparedStatement.setString(1, usernameOrEmail);
		ResultSet result = preparedStatement.executeQuery();
		return result;

	}
	
	public void clientVersion0(Connection connection, Socket socket) throws IOException, ExceptionProtocol, SQLException, NoSuchAlgorithmException, InvalidKeySpecException
	{
		InputStream in = socket.getInputStream();
		OutputStream out = socket.getOutputStream();
		// read MESSAGE length
		Message.readInt(in);
		int message = Message.readInt(in);
		switch (message)
		{
			case Message.MESSAGE_CLIENT_CREATE_USER:
			{
				String username = Message.readString(in);
				String email = Message.readString(in);
				String password = Message.readString(in);
				PreparedStatement preparedStatement;
				ResultSet resultSet;
				preparedStatement = connection.prepareStatement("SELECT * FROM t_user WHERE name = ?;");
				preparedStatement.setString(1, username);
				resultSet = preparedStatement.executeQuery();
				if (resultSet.next() || username.length() == 0)
				{
					Message.messageSimple(out, Message.MESSAGE_SERVER_CREATE_USER_ERROR_USERNAME);
				}
				else
				{
					preparedStatement = connection.prepareStatement("SELECT * FROM t_user WHERE email = ?;");
					preparedStatement.setString(1, email);
					resultSet = preparedStatement.executeQuery();
					if (resultSet.next() || email.length() == 0 || !email.contains("@"))
					{
						Message.messageSimple(out, Message.MESSAGE_SERVER_CREATE_USER_ERROR_EMAIL);
					}
					else
					{
						byte[] salt = Password.getSalt();
						String passwordhash = Password.hash(password, salt);
						preparedStatement = connection.prepareStatement("INSERT INTO t_user (name, email, passwordhash, passwordsalt) VALUES (?, ?, ?, ?);");
						preparedStatement.setString(1, username);
						preparedStatement.setString(2, email);
						preparedStatement.setString(3, passwordhash);
						preparedStatement.setString(4, Base64.encodeBytes(salt));
						preparedStatement.execute();
						connection.commit();
						Message.messageSimple(out, Message.MESSAGE_SERVER_CREATE_USER_SUCCESS);
					}
				}
				break;
			}
			case Message.MESSAGE_CLIENT_LOGIN:
			{
				String usernameOrEmail = Message.readString(in);
				String password = Message.readString(in);
			
				ResultSet resultSet = getUser(connection, usernameOrEmail);
				if (resultSet.next())
				{
					String username = resultSet.getString("name");
					String email = resultSet.getString("email");
					String passwordHash = resultSet.getString("passwordhash");
					byte[] salt = Base64.decode(resultSet.getString("passwordsalt"));
					if (Password.check(password, salt, passwordHash))
					{
						Message.messageServerLoginSuccess(out, username);
						new User(this, connection, socket, username, email).processMessages();
					}
					else
					{
						Message.messageSimple(out, Message.MESSAGE_SERVER_LOGIN_ERROR);
					}
				}
				else
				{
					Message.messageSimple(out, Message.MESSAGE_SERVER_LOGIN_ERROR);
				}
				break;
			}
			default:
			{
				throw new ExceptionProtocol();
			}
		}
	}

	public void client(Connection connection, Socket socket) throws IOException, SQLException, ExceptionProtocol, NoSuchAlgorithmException, InvalidKeySpecException
	{
		InputStream in = socket.getInputStream();
		switch (Message.readMagicVersion(in))
		{
			case 0:
				clientVersion0(connection, socket);
				break;
			default:
				throw new ExceptionProtocol();
		}
	}

	public void start() throws IOException, SQLException
	{
		@SuppressWarnings("resource")
		ServerSocket serverSocket = new ServerSocket(Default.HOSTPORT);
		while (true)
		{
			final Connection connection = DriverManager.getConnection("jdbc:postgresql://" + Default.DATABASE_HOSTNAME + "/" + Default.DATABASE_NAME, Default.DATABASE_USERNAME, Default.DATABASE_PASSWORD);
			connection.setAutoCommit(false);
			final Socket socket = serverSocket.accept();
			new Thread()
			{
				public void run()
				{
					try
					{
						socket.setSoTimeout(Default.TIMEOUT);
						client(connection, socket);
					}
					catch (IOException exception)
					{
						exception.printStackTrace();
					}
					catch (SQLException exception)
					{
						exception.printStackTrace();
					}
					catch (ExceptionProtocol exception)
					{
						exception.printStackTrace();
					}
					catch (NoSuchAlgorithmException exception)
					{
						exception.printStackTrace();
					}
					catch (InvalidKeySpecException exception)
					{
						exception.printStackTrace();
					}
					try
					{
						connection.close();
					}
					catch (SQLException exception)
					{
						exception.printStackTrace();
					}
					try
					{
						socket.close();
					}
					catch (IOException exception)
					{
						exception.printStackTrace();
					}
				}
			}.start();
		}
		//		serverSocket.close();
	}

	public static final void main(String[] arguments)
	{
		try
		{
			Class.forName("org.postgresql.Driver");
			new FrebbleServer().start();
		}
		catch (IOException exception)
		{
			exception.printStackTrace();
		}
		catch (ClassNotFoundException exception)
		{
			exception.printStackTrace();
		}
		catch (SQLException exception)
		{
			exception.printStackTrace();
		}
	}
}