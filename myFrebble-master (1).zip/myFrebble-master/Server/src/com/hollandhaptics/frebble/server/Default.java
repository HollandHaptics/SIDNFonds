package com.hollandhaptics.frebble.server;

public class Default
{
	public static final String HOSTNAME = "oscar.novit.nl";
	public static final int HOSTPORT = 13145;
	public static final String DATABASE_HOSTNAME = "localhost";
	public static final String DATABASE_NAME = "frebble";
	public static final String DATABASE_USERNAME = "frebble";
	public static final String DATABASE_PASSWORD = "frebble";
	public static final int VERSION = 0;
	public static final int MAGICNUMBER = 0x4A3B2C1D;
	public static final int TIMEOUT = 120 * 60 * 100;
	public static final int PASSWORD_ITERATIONS = 250000;
	public static final int PASSWORD_SALT_LENGTH = 32;
	public static final int PASSWORD_KEY_LENGTH = 256;
	public static final int FREBBLE_DELAY = 250;
}