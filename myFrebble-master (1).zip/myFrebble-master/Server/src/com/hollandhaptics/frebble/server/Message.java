package com.hollandhaptics.frebble.server;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;

public class Message
{
	public static final int MESSAGE_CLIENT_CREATE_USER = 0;
	public static final int MESSAGE_CLIENT_LOGIN = 1;
	public static final int MESSAGE_CLIENT_SESSION_INVITE = 2;
	public static final int MESSAGE_CLIENT_SESSION_VALUE = 3;
	public static final int MESSAGE_CLIENT_SESSION_STOP = 4;
	public static final int MESSAGE_SERVER_CREATE_USER_SUCCESS = 0;
	public static final int MESSAGE_SERVER_CREATE_USER_ERROR_USERNAME = 1;
	public static final int MESSAGE_SERVER_CREATE_USER_ERROR_EMAIL = 2;
	public static final int MESSAGE_SERVER_LOGIN_SUCCES = 3;
	public static final int MESSAGE_SERVER_LOGIN_ERROR = 4;
	public static final int MESSAGE_SERVER_SESSION_INVITE = 5;
	public static final int MESSAGE_SERVER_SESSION_INVITING = 6;
	public static final int MESSAGE_SERVER_SESSION_START = 7;
	public static final int MESSAGE_SERVER_SESSION_VALUE = 8;
	public static final int MESSAGE_SERVER_SESSION_STOP = 9;
	public static final int MESSAGE_SERVER_SESSION_ERROR_PARTNER_OFFLINE = 10;
	public static final int MESSAGE_SERVER_SESSION_ERROR_PARTNER_NOTEXIST = 11;
	public static final int MESSAGE_SERVER_SESSION_ERROR_PARTNER_BUSY = 12;

	private static ByteBuffer getByteBuffer(int messageLength)
	{
		ByteBuffer result = ByteBuffer.allocate(4 + messageLength);
		result.order(ByteOrder.BIG_ENDIAN);
		result.putInt(4 + messageLength);
		return result;
	}

	public static int readInt(InputStream in) throws IOException, ExceptionProtocol
	{
		int result;
		byte[] bytes = new byte[4];
		if (in.read(bytes) == 4)
		{
			ByteBuffer byteBuffer = ByteBuffer.wrap(bytes);
			byteBuffer.order(ByteOrder.BIG_ENDIAN);
			result = byteBuffer.getInt();
		}
		else
		{
			throw new ExceptionProtocol();
		}
//				System.out.println("in: " + result);
		return result;
	}

	public static String readString(InputStream in) throws IOException, ExceptionProtocol
	{
		String result = "";
		int length = readInt(in);
		for (int index = 0; index < length; index++)
		{
			result += (char) in.read();
		}
//				System.out.println("in: " + result);
		return result;
	}

	public static int readMagicVersion(InputStream in) throws ExceptionProtocol, IOException
	{
		int result;
		if (readInt(in) == Default.MAGICNUMBER)
		{
			result = readInt(in);
		}
		else
		{
			throw new ExceptionProtocol();
		}
		return result;
	}

	private static void write(OutputStream out, ByteBuffer byteBuffer)
	{
		byteBuffer.flip();
		synchronized (out)
		{
			try
			{
				out.write(byteBuffer.array());
			}
			catch (IOException exception)
			{
				exception.printStackTrace();
			}
		}
	}

	private static void writeInt(OutputStream out, int value)
	{
		ByteBuffer byteBuffer = ByteBuffer.allocate(4);
		byteBuffer.order(ByteOrder.BIG_ENDIAN);
		byteBuffer.putInt(value);
		write(out, byteBuffer);
	}

	private static void writeString(ByteBuffer byteBuffer, String string)
	{
		byteBuffer.putInt(string.length());
		for (int index = 0; index < string.length(); index++)
		{
			byteBuffer.put((byte) string.charAt(index));
		}
	}

	public static void writeMagicVersion(OutputStream out)
	{
		writeInt(out, Default.MAGICNUMBER);
		writeInt(out, Default.VERSION);
	}

	public static void messageSimple(OutputStream out, int message)
	{
		ByteBuffer byteBuffer = getByteBuffer(4);
		byteBuffer.putInt(message);
		write(out, byteBuffer);
	}

	public static void messageClientCreateUser(OutputStream out, String username, String email, String passwordhash)
	{
		ByteBuffer byteBuffer = getByteBuffer(4 + 4 + username.length() + 4 + email.length() + 4 + passwordhash.length());
		byteBuffer.putInt(MESSAGE_CLIENT_CREATE_USER);
		writeString(byteBuffer, username);
		writeString(byteBuffer, email);
		writeString(byteBuffer, passwordhash);
		write(out, byteBuffer);
	}

	public static void messageClientLogin(OutputStream out, String usernameOrEmail, String passwordhash)
	{
		ByteBuffer byteBuffer = getByteBuffer(4 + 4 + usernameOrEmail.length() + 4 + passwordhash.length());
		byteBuffer.putInt(MESSAGE_CLIENT_LOGIN);
		writeString(byteBuffer, usernameOrEmail);
		writeString(byteBuffer, passwordhash);
		write(out, byteBuffer);
	}

	public static void messageClientSessionInvite(OutputStream out, String usernameOrEmail)
	{
		ByteBuffer byteBuffer = getByteBuffer(4 + 4 + usernameOrEmail.length());
		byteBuffer.putInt(MESSAGE_CLIENT_SESSION_INVITE);
		writeString(byteBuffer, usernameOrEmail);
		write(out, byteBuffer);
	}

	public static void messageClientSessionValue(OutputStream out, int value)
	{
		ByteBuffer byteBuffer = getByteBuffer(4 + 4);
		byteBuffer.putInt(MESSAGE_CLIENT_SESSION_VALUE);
		byteBuffer.putInt(value);
		write(out, byteBuffer);
	}

	public static void messageServerLoginSuccess(OutputStream out, String username)
	{
		ByteBuffer byteBuffer = getByteBuffer(4 + 4 + username.length());
		byteBuffer.putInt(MESSAGE_SERVER_LOGIN_SUCCES);
		writeString(byteBuffer, username);
		write(out, byteBuffer);
	}

	public static void messageServerSessionInvite(OutputStream out, String usernameOrEmail)
	{
		ByteBuffer byteBuffer = getByteBuffer(4 + 4 + usernameOrEmail.length());
		byteBuffer.putInt(MESSAGE_SERVER_SESSION_INVITE);
		writeString(byteBuffer, usernameOrEmail);
		write(out, byteBuffer);
	}

	public static void messageServerSessionInviting(OutputStream out, String usernameOrEmail)
	{
		ByteBuffer byteBuffer = getByteBuffer(4 + 4 + usernameOrEmail.length());
		byteBuffer.putInt(MESSAGE_SERVER_SESSION_INVITING);
		writeString(byteBuffer, usernameOrEmail);
		write(out, byteBuffer);
	}

	public static void messageServerSessionStart(OutputStream out, String usernameOrEmail)
	{
		ByteBuffer byteBuffer = getByteBuffer(4 + 4 + usernameOrEmail.length());
		byteBuffer.putInt(MESSAGE_SERVER_SESSION_START);
		writeString(byteBuffer, usernameOrEmail);
		write(out, byteBuffer);
	}

	public static void messageServerSessionValue(OutputStream out, int value)
	{
		ByteBuffer byteBuffer = getByteBuffer(4 + 4);
		byteBuffer.putInt(MESSAGE_SERVER_SESSION_VALUE);
		byteBuffer.putInt(value);
		write(out, byteBuffer);
	}
}
