package com.hollandhaptics.frebble.server;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;

public class User
{
	private FrebbleServer frebbleServer_;
	private Connection connection_;
	private Socket socket_;
	private InputStream inputStream_;
	private OutputStream outputStream_;
	private String username_;
	private String email_;
	private User partner_;
	private boolean accepted_;
	private long timestamp_;
	public ThreadValue threadValue_;

	public User(FrebbleServer frebbleServer, Connection connection, Socket socket, String username, String email) throws IOException
	{
		frebbleServer_ = frebbleServer;
		connection_ = connection;
		socket_ = socket;
		inputStream_ = socket_.getInputStream();
		outputStream_ = socket_.getOutputStream();
		username_ = username;
		email_ = email;
		partner_ = null;
		accepted_ = false;
		timestamp_ = 0;
		threadValue_ = null;
		synchronized (getFrebbleServer())
		{
			User user = getFrebbleServer().getUsers().get(getUsername());
			if (user != null)
			{
				user.terminate();
			}
			getFrebbleServer().getUsers().put(getUsername(), this);
			getFrebbleServer().getEmail2username().put(getEmail(), getUsername());
		}
	}

	public FrebbleServer getFrebbleServer()
	{
		return frebbleServer_;
	}

	public String getUsername()
	{
		return username_;
	}

	public String getEmail()
	{
		return email_;
	}

	public User getPartner()
	{
		return partner_;
	}

	public boolean getAccepted()
	{
		return accepted_;
	}

	public InputStream getInputStream() throws IOException
	{
		return inputStream_;
	}

	public OutputStream getOutputStream()
	{
		return outputStream_;
	}

	public void processMessages() throws SQLException
	{
		try
		{
			while (true)
			{
				// read MESSAGE length
				Message.readInt(getInputStream());
				int message = Message.readInt(getInputStream());
				switch (message)
				{
					case Message.MESSAGE_CLIENT_LOGIN:
					{
						break;
					}
					case Message.MESSAGE_CLIENT_SESSION_INVITE:
					{
						String usernameOrEmail = Message.readString(getInputStream());
						synchronized (getFrebbleServer())
						{
							User partner;
							if (usernameOrEmail.contains("@"))
							{
								String username = getFrebbleServer().getEmail2username().get(usernameOrEmail);
								if (username == null)
								{
									partner = null;
								}
								else
								{
									partner = getFrebbleServer().getUsers().get(username);
								}
							}
							else
							{
								partner = getFrebbleServer().getUsers().get(usernameOrEmail);
							}
							if (partner == null)
							{
								ResultSet resultSet = FrebbleServer.getUser(connection_, usernameOrEmail);
								if (resultSet.next())
								{
									Message.messageSimple(getOutputStream(), Message.MESSAGE_SERVER_SESSION_ERROR_PARTNER_OFFLINE);
								}
								else
								{
									Message.messageSimple(getOutputStream(), Message.MESSAGE_SERVER_SESSION_ERROR_PARTNER_NOTEXIST);
								}
							}
							else
							{
								if ((partner != this && getPartner() == null && partner.getPartner() == null) || getPartner() == partner)
								{
									partner_ = partner;
									getPartner().partner_ = this;
									accepted_ = true;
									if (partner.getAccepted())
									{
										Message.messageServerSessionStart(getOutputStream(), getPartner().getUsername());
										Message.messageServerSessionStart(getPartner().getOutputStream(), getUsername());
									}
									else
									{
										Message.messageServerSessionInviting(getOutputStream(), getPartner().getUsername());
										Message.messageServerSessionInvite(getPartner().getOutputStream(), getUsername());
									}
								}
								else
								{
									Message.messageSimple(getOutputStream(), Message.MESSAGE_SERVER_SESSION_ERROR_PARTNER_BUSY);
								}
							}
						}
						break;
					}
					case Message.MESSAGE_CLIENT_SESSION_VALUE:
					{
						int value = Message.readInt(getInputStream());
						synchronized (getFrebbleServer())
						{
							if (getAccepted() && getPartner().getAccepted())
							{
								synchronized (this)
								{
									long timestamp = System.currentTimeMillis();
									if (threadValue_ == null)
									{
										long sleep = Math.max(0, Default.FREBBLE_DELAY - (timestamp - timestamp_));
										System.out.println("user: " + getUsername() + "sleep: " + sleep);
										threadValue_ = new ThreadValue(this, value, sleep);
										threadValue_.start();
										timestamp_ = timestamp + sleep;
									}
									else
									{
										threadValue_.setValue(value);
									}
								}
							}
						}
						break;
					}
					case Message.MESSAGE_CLIENT_SESSION_STOP:
					{
						sessionStop();
						break;
					}
				}
			}
		}
		catch (IOException | ExceptionProtocol exception)
		{
			exception.printStackTrace();
		}
		try
		{
			terminate();
		}
		catch (IOException exception)
		{
			exception.printStackTrace();
		}
	}

	public void sessionStop()
	{
		synchronized (getFrebbleServer())
		{
			if (threadValue_ != null)
			{
				threadValue_.disable();
			}
			if (getPartner() != null)
			{
				Message.messageSimple(getOutputStream(), Message.MESSAGE_SERVER_SESSION_STOP);
				Message.messageSimple(getPartner().getOutputStream(), Message.MESSAGE_SERVER_SESSION_STOP);
				getPartner().accepted_ = false;
				accepted_ = false;
				getPartner().partner_ = null;
				partner_ = null;
			}
		}
	}

	public void terminate() throws IOException
	{
		System.out.println("terminate() {");
		synchronized (getFrebbleServer())
		{
			if (getFrebbleServer().getUsers().get(getUsername()) == this)
			{
				getFrebbleServer().getUsers().remove(getUsername());
				System.out.println("users: " + getFrebbleServer().getUsers().size());
				getFrebbleServer().getEmail2username().remove(getEmail());
			}
			sessionStop();
			if (socket_ != null)
			{
				socket_.close();
				socket_ = null;
			}
		}
		System.out.println("terminate() }");
	}
}