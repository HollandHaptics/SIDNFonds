package com.hollandhaptics.frebble.server;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;

import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

import org.postgresql.util.Base64;

public class Password
{
	public static byte[] getSalt() throws NoSuchAlgorithmException
	{
		return SecureRandom.getInstance("SHA1PRNG").generateSeed(Default.PASSWORD_SALT_LENGTH);
	}

	public static boolean check(String password, byte[] salt, String passwordHash) throws NoSuchAlgorithmException, InvalidKeySpecException
	{
		return hash(password, salt).equals(passwordHash);
	}

	public static String hash(String password, byte[] salt) throws NoSuchAlgorithmException, InvalidKeySpecException
	{
		SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
		SecretKey secretKey = secretKeyFactory.generateSecret(new PBEKeySpec(password.toCharArray(), salt, Default.PASSWORD_ITERATIONS, Default.PASSWORD_KEY_LENGTH));
		return Base64.encodeBytes(secretKey.getEncoded());
	}
}