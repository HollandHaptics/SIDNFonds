package com.hollandhaptics.frebble.server.test;

import java.io.IOException;
import java.net.Socket;

import com.hollandhaptics.frebble.server.Default;
import com.hollandhaptics.frebble.server.ExceptionProtocol;
import com.hollandhaptics.frebble.server.Message;

public class FrebbleTest
{
	public static Socket getSocket() throws IOException
	{
		Socket result = new Socket(Default.HOSTNAME, Default.HOSTPORT);
		Message.writeMagicVersion(result.getOutputStream());
		return result;
	}

	public static final void printMessageLogin(String prefix, Socket socket) throws IOException, ExceptionProtocol
	{
		// read MESSAGE length
		Message.readInt(socket.getInputStream());
		switch (Message.readInt(socket.getInputStream()))
		{
			case Message.MESSAGE_SERVER_LOGIN_SUCCES:
				System.out.println(prefix + ": login succesful: " + Message.readString(socket.getInputStream()));
				break;
			case Message.MESSAGE_SERVER_LOGIN_ERROR:
				System.out.println(prefix + ": login error");
				break;
			default:
				throw new ExceptionProtocol();
		}
	}

	public static final void printMessageInvite(String prefix, Socket socket) throws IOException, ExceptionProtocol
	{
		// read MESSAGE length
		Message.readInt(socket.getInputStream());
		switch (Message.readInt(socket.getInputStream()))
		{
			case Message.MESSAGE_SERVER_SESSION_INVITE:
				System.out.println(prefix + ": invited by: " + Message.readString(socket.getInputStream()));
				break;
			case Message.MESSAGE_SERVER_SESSION_INVITING:
				System.out.println(prefix + ": inviting: " + Message.readString(socket.getInputStream()));
				break;
			default:
				throw new ExceptionProtocol();
		}
	}

	public static final void printMessageStartStop(String prefix, Socket socket) throws IOException, ExceptionProtocol
	{
		// read MESSAGE length
		Message.readInt(socket.getInputStream());
		switch (Message.readInt(socket.getInputStream()))
		{
			case Message.MESSAGE_SERVER_SESSION_START:
				System.out.println(prefix + ": session started with: " + Message.readString(socket.getInputStream()));
				break;
			case Message.MESSAGE_SERVER_SESSION_STOP:
				System.out.println(prefix + ": session stopped");
				break;
			default:
				throw new ExceptionProtocol();
		}
	}

	public static final void printMessageValue(String prefix, Socket socket) throws IOException, ExceptionProtocol
	{
		// read MESSAGE length
		Message.readInt(socket.getInputStream());
		switch (Message.readInt(socket.getInputStream()))
		{
			case Message.MESSAGE_SERVER_SESSION_VALUE:
				System.out.println(prefix + ": value: " + Message.readInt(socket.getInputStream()));
				break;
			default:
				throw new ExceptionProtocol();
		}
	}

	public static final void test1()
	{
		try
		{
			Socket socketA;
			Socket socketB;
			Socket socketC;
			Socket socketD;
			socketA = getSocket();
			socketB = getSocket();
			socketC = getSocket();
			socketD = getSocket();
			Message.messageClientLogin(socketA.getOutputStream(), "a", "a");
			printMessageLogin("A", socketA);
			Message.messageClientLogin(socketB.getOutputStream(), "b@", "b");
			printMessageLogin("B", socketB);
			Message.messageClientLogin(socketC.getOutputStream(), "c@", "c");
			printMessageLogin("C", socketC);
			Message.messageClientLogin(socketD.getOutputStream(), "d@", "d");
			printMessageLogin("D", socketD);
			Message.messageClientSessionInvite(socketA.getOutputStream(), "b");
			printMessageInvite("A", socketA);
			printMessageInvite("B", socketB);
			Message.messageClientSessionInvite(socketB.getOutputStream(), "a");
			printMessageStartStop("A", socketA);
			printMessageStartStop("B", socketB);
			Message.messageClientSessionInvite(socketC.getOutputStream(), "a");
			printMessageStartStop("C", socketC);
			Message.messageClientSessionValue(socketA.getOutputStream(), 15);
			printMessageValue("B", socketB);
			Message.messageSimple(socketB.getOutputStream(), Message.MESSAGE_SERVER_SESSION_STOP);
			printMessageStartStop("A", socketA);
			Message.messageClientSessionInvite(socketC.getOutputStream(), "a");
			printMessageInvite("A", socketA);
			printMessageInvite("C", socketC);
		}
		catch (IOException exception)
		{
			exception.printStackTrace();
		}
		catch (ExceptionProtocol exception)
		{
			exception.printStackTrace();
		}
	}

	public static final void test2()
	{
		try
		{
			Socket socket;
			socket = getSocket();
			Message.messageClientLogin(socket.getOutputStream(), "c", "c");
			printMessageLogin("C", socket);
			Message.messageClientSessionInvite(socket.getOutputStream(), "a");
			printMessageInvite("C", socket);
			printMessageStartStop("C", socket);
			for (int force = 0; force <= 200; force++)
			{
				Thread.sleep(50);
				Message.messageClientSessionValue(socket.getOutputStream(), force);				
			}
//			for (int force = 200; force >= 0; force--)
//			{
//				Thread.sleep(100);
//				Message.messageClientSessionValue(socketB.getOutputStream(), force);				
//			}
			
		}
		catch (IOException exception)
		{
			exception.printStackTrace();
		}
		catch (ExceptionProtocol exception)
		{
			exception.printStackTrace();
		}
		catch (InterruptedException exception)
		{
			exception.printStackTrace();
		}
	}

	public static final void main(String[] arguments)
	{
		test2();
	}
}
