package com.hollandhaptics.frebble.server;

public class ThreadValue extends Thread
{
	private User user_;
	private int value_;
	private long sleep_;
	private boolean active_;

	public ThreadValue(User user, int value, long sleep)
	{
		user_ = user;
		value_ = value;
		sleep_ = sleep;
		active_ = true;
	}

	public void run()
	{
		try
		{
			sleep(sleep_);
			synchronized (user_)
			{
				user_.threadValue_ = null;
				if (active_)
				{
					Message.messageServerSessionValue(user_.getPartner().getOutputStream(), value_);
				}
			}
		}
		catch (InterruptedException exception)
		{
			exception.printStackTrace();
		}
	}

	public void setValue(int value)
	{
		value_ = value;
	}

	public void disable()
	{
		synchronized (user_)
		{
			active_ = false;
		}
	}
}