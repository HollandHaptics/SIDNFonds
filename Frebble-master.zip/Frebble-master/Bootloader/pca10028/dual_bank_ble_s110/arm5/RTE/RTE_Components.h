
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'bootloader' 
 * Target:  'nrf51422_xxac' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define BSP_DEFINES_ONLY
#define S110
#define SOFTDEVICE_PRESENT

#endif /* RTE_COMPONENTS_H */
