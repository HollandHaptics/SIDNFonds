# Frebble
Device Firmware - v 3.0.0


---

1. Program SoftDevice S110 8.0.0 using nRFgo Studio (with SoftDevice protection disabled)
2. Upload the Bootloader using Keil uVision (so it uses nrfjprog.exe for flash programming. This is set in the target options under Utilities)
3. Upload the application image found in ~/Bin/ with the Master Control Panel (must be an OTA update)

---

NB To create a new image:

Start Command Prompt.

First create the bin file:

1. Go to: ~\Keil_v5\ARM\ARMCC\bin
2. Run: fromelf.exe --bin --output "C:\Bin\Frebble.bin" "C:\frebble\nRF51\s110\arm5\_build\nrf51822_xxac_s110.axf"

(Where C:\Bin\Frebble.bin specifies the bin file to create, and C:\frebble\nRF51\s110\arm5\_build\nrf51822_xxac_s110.axf points to the project's axf file to use)


Next create the zip archive (containing the Init packet file):

1. Go to: C:\Program Files (x86)\Nordic Semiconductor\Master Control Panel\3.9.0.6\nrf
2. Run: nrf.exe dfu genpkg "C:\Bin\Frebble.zip" --application "C:\Bin\Frebble.bin" --application-version 0xffff --dev-revision 0xffff --dev-type 0xffff --sd-req 0x0064

(Where C:\Bin\Frebble.zip specifies the zip archive to create, and C:\Bin\Frebble.bin points to the bin file to use. For an overview of the flags see the Nordic docs)
