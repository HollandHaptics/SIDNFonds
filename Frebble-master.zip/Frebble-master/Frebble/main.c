/* Copyright (c) 2015 Holland Haptics BV. All Rights Reserved.
 *
 * Written by: Johny Gorissen
 * Last update: 15-12-2015
 */

/** @file
 *
 * @defgroup hollandhaptics_frebble main.c
 * @{
 * @ingroup  hollandhaptics_frebble
 * @brief    Frebble application main file.
 *
 * This file contains the source code for the Frebble firmware application.
 */



#include <stdbool.h>
#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <Math.h>

#include "nordic_common.h"
#include "nrf.h"
#include "nrf51_bitfields.h"
#include "ble_hci.h"
#include "ble_advdata.h"
#include "ble_conn_params.h"
#include "softdevice_handler.h"
#include "app_timer.h"
#include "nrf_gpio.h"
#include "app_gpiote.h"
#include "app_button.h"
#include "ble_nus.h"
#include "app_uart.h"
#include "app_util_platform.h"
#include "bsp.h"

#include "app_util.h"
#include "app_error.h"
#include "ble.h"
#include "ble_advertising.h"
#include "ble_srv_common.h"
#include "ble_bas.h"
#include "ble_dis.h"
#include "softdevice_handler.h"
#include "boards.h"
#include "nrf_delay.h"

#include "device_manager.h"
#include "pstorage.h"
#include "app_trace.h"

#ifdef BLE_DFU_APP_SUPPORT
#include "ble_dfu.h"
#include "dfu_app_handler.h"
#endif // BLE_DFU_APP_SUPPORT

#include "nrf_pwm.h"
#include "ble_radio_notification.h"
#include "neopixel.h"



// Input Pins
#define PIN_SEN                          5       // ADC6: p0.05: Sensor
#define PIN_VBAT_ADC                     2       // ADC3: p0.02: VBat-ADC
#define PIN_CHARGE_STATUS                12      // p0.12: Charge Status
#define PIN_CHARGE_DONE                  13      // p0.13: Charging done
#define PIN_ADAPTER_PRESENT              14      // p0.14: Adapter Present

// Output Pins
#define PIN_SOL                          22      // p0.22: Solenoid
#define PIN_MOSILED                      28      // p0.28: MOSI/LED
#define PIN_LEDPWR                       29      // p0.29: LED pwr

// Device Information
#define DEVICE_NAME                      "Frebble"
#define STATIC_PASSKEY                   "000000"                                   /**< Static pin. (6 digits) */
#define MANUFACTURER_NAME                "Holland Haptics BV"
#define MODEL_NUMBER                     "Kickstarter"
#define SERIAL_NUMBER                    "HH-01-KS"
#define HARDWARE_REVISION                "1.0.0"
#define FIRMWARE_REVISION                "3.0.0"
#define SOFTWARE_REVISION                "1.0.0"


#define IS_SRVC_CHANGED_CHARACT_PRESENT 1                                           /**< Include the service_changed characteristic. If not enabled, the server's database cannot be changed for the lifetime of the device. */
#define APP_ADV_INTERVAL                64                                          /**< The advertising interval (in units of 0.625 ms. This value corresponds to 40 ms). */
#define APP_ADV_TIMEOUT_IN_SECONDS      60 //max180                                 /**< The advertising timeout (in units of seconds). */

#define APP_TIMER_PRESCALER             0                                           /**< Value of the RTC1 PRESCALER register. */
#define APP_TIMER_MAX_TIMERS            4                                           /**< Maximum number of simultaneously created timers. */
#define APP_TIMER_OP_QUEUE_SIZE         4                                           /**< Size of timer operation queues. */

#define APP_GPIOTE_MAX_USERS            1                                           /**< Maximum number of simultaneously GPIOTE users. */

#define MIN_CONN_INTERVAL               MSEC_TO_UNITS(20, UNIT_1_25_MS)             /**< Minimum acceptable connection interval (20 ms), Connection interval uses 1.25 ms units. */
#define MAX_CONN_INTERVAL               MSEC_TO_UNITS(75, UNIT_1_25_MS)             /**< Maximum acceptable connection interval (75 ms), Connection interval uses 1.25 ms units. */
#define SLAVE_LATENCY                   0                                           /**< Slave latency. */
#define CONN_SUP_TIMEOUT                MSEC_TO_UNITS(4000, UNIT_10_MS)             /**< Connection supervisory timeout (4 seconds), Supervision Timeout uses 10 ms units. */
#define FIRST_CONN_PARAMS_UPDATE_DELAY  APP_TIMER_TICKS(5000, APP_TIMER_PRESCALER)  /**< Time from initiating event (connect or start of notification) to first time sd_ble_gap_conn_param_update is called (5 seconds). */
#define NEXT_CONN_PARAMS_UPDATE_DELAY   APP_TIMER_TICKS(30000, APP_TIMER_PRESCALER) /**< Time between each call to sd_ble_gap_conn_param_update after the first call (30 seconds). */
#define MAX_CONN_PARAMS_UPDATE_COUNT    3                                           /**< Number of attempts before giving up the connection parameter negotiation. */

#define BUTTON_DETECTION_DELAY          APP_TIMER_TICKS(50, APP_TIMER_PRESCALER)    /**< Delay from a GPIOTE event until a button is reported as pushed (in number of timer ticks). */

#define SEC_PARAM_BOND                  1                                           /**< Perform bonding. */
#define SEC_PARAM_MITM                  1                                           /**< Man In The Middle protection not required. */
#define SEC_PARAM_IO_CAPABILITIES       BLE_GAP_IO_CAPS_DISPLAY_ONLY                /**< IO set to Display Only to enable static passkey. */
#define SEC_PARAM_OOB                   0                                           /**< Out Of Band data not available. */
#define SEC_PARAM_MIN_KEY_SIZE          7                                           /**< Minimum encryption key size. */
#define SEC_PARAM_MAX_KEY_SIZE          16                                          /**< Maximum encryption key size. */

#define DEAD_BEEF                       0xDEADBEEF                                  /**< Value used as error code on stack dump, can be used to identify stack location on stack unwind. */

#define BATTERY_LEVEL_MEAS_INTERVAL      APP_TIMER_TICKS(2000, APP_TIMER_PRESCALER) /**< Battery level measurement interval (ticks). */

#ifdef BLE_DFU_APP_SUPPORT
  #define DFU_REV_MAJOR                 0x00                                        /** DFU Major revision number to be exposed. */
  #define DFU_REV_MINOR                 0x01                                        /** DFU Minor revision number to be exposed. */
  #define DFU_REVISION                  ((DFU_REV_MAJOR << 8) | DFU_REV_MINOR)      /** DFU Revision number to be exposed. Combined of major and minor versions. */
  #define APP_SERVICE_HANDLE_START      0x000C                                      /**< Handle of first application specific service when when service changed characteristic is present. */
  #define BLE_HANDLE_MAX                0xFFFF                                      /**< Max handle value in BLE. */

  STATIC_ASSERT(IS_SRVC_CHANGED_CHARACT_PRESENT);                                   /** When having DFU Service support in application the Service Changed Characteristic should always be present. */
#endif // BLE_DFU_APP_SUPPORT

#define PWM_CONFIG                      PWM_MODE_MTR_100

#define constrain(amt,low,high)         ((amt)<(low)?(low):((amt)>(high)?(high):(amt)))



static ble_gap_sec_params_t             m_sec_params;                               /**< Security requirements for this application. */
static ble_nus_t                        m_nus;                                      /**< Structure to identify the Nordic UART Service. */
static ble_bas_t                        m_bas;                                      /**< Structure used to identify the battery service. */
static uint16_t                         m_conn_handle = BLE_CONN_HANDLE_INVALID;    /**< Handle of the current connection. */

static app_timer_id_t                   m_battery_timer_id;                         /**< Battery timer. */

static dm_application_instance_t        m_app_handle;                               /**< Application identifier allocated by device manager */

#ifdef BLE_DFU_APP_SUPPORT
  static ble_dfu_t                      m_dfus;                                     /**< Structure used to identify the DFU service. */
#endif // BLE_DFU_APP_SUPPORT  

static ble_opt_t                        m_static_pin_option;                        /**< Pointer to the struct containing static pin option. */

static bool                             new_adc_sample_ready = false;
static uint8_t                          val_in = 0;
static uint8_t                          prev_val_in = 0;
static uint8_t                          val_out_sol = 0;
static uint16_t                         adc_result = 0;
static uint16_t                         adc_result2 = 0;
static uint8_t                          min_val_in = 30;
static double                           max_val_in = 200.0;
static double                           max_pwm_value = 0.0;

static bool                             connected = false;
static bool                             battery_empty = false;

static neopixel_strip_t                 m_strip;
static uint16_t                         leds_per_strip = 2;

static uint8_t                          red_connected = 4U;
static uint8_t                          green_connected = 146U;
static uint8_t                          blue_connected = 184U;
static uint8_t                          red_squeeze = 255U - 4U;
static uint8_t                          green_squeeze = 255U - 146U;
static uint8_t                          blue_squeeze = 255U - 184U;
static uint8_t                          red_battery_empty = 255U;
static uint8_t                          green_battery_empty = 0U;
static uint8_t                          blue_battery_empty = 0U;
static uint8_t                          red_battery_charged = 0U;
static uint8_t                          green_battery_charged = 255U;
static uint8_t                          blue_battery_charged = 0U;
static uint8_t                          red_dfu = 255U;
static uint8_t                          green_dfu = 0U;
static uint8_t                          blue_dfu = 255U;

static bool                             SOL_ENABLED = true;
static bool                             charging_done = false;
static uint8_t                          attempt = 0;



/** @brief  Function to return the color value (0-255) between two colors and a given transition (0-100%)
 */
uint8_t getColor(uint8_t color_from, uint8_t color_to, double transition) {
  return (uint8_t)((double)color_from + ((((double)color_to - (double)color_from) / 100) * (double)constrain(transition, 0, 100)));
}

/**
 * ADC functions (Sensor & Battery)
 */
void readSensor() {
    // Interrupt ADC
    NRF_ADC->INTENSET = (ADC_INTENSET_END_Disabled << ADC_INTENSET_END_Pos);         /*!< Interrupt enabled. */
          
    // Config ADC
    NRF_ADC->CONFIG  = (ADC_CONFIG_EXTREFSEL_None << ADC_CONFIG_EXTREFSEL_Pos)       /* Bits 17..16 : ADC external reference pin selection. */
                    | (ADC_CONFIG_PSEL_AnalogInput6 << ADC_CONFIG_PSEL_Pos)          /*!< Use analog input 0 as analog input. */
                    | (ADC_CONFIG_REFSEL_VBG << ADC_CONFIG_REFSEL_Pos)               /*!< Use internal 1.2V bandgap voltage as reference for conversion. */
                    | (ADC_CONFIG_INPSEL_AnalogInputOneThirdPrescaling << ADC_CONFIG_INPSEL_Pos) /*!< Analog input specified by PSEL with no prescaling used as input for the conversion. */
                    | (ADC_CONFIG_RES_10bit << ADC_CONFIG_RES_Pos);                  /*!< 10bit ADC resolution. */ 
  
    // Enable ADC    
    NRF_ADC->ENABLE = ADC_ENABLE_ENABLE_Enabled;                                     /* Bit 0 : ADC enable. */    
  
    // Start ADC conversion
    NRF_ADC->TASKS_START = 1;
  
    // Wait for conversion to end
    while( !NRF_ADC->EVENTS_END ) {}
    NRF_ADC->EVENTS_END  = 0;
  
    // Save your ADC result
    adc_result = NRF_ADC->RESULT;  
    
    // Use the STOP task to save current. Workaround for PAN_028 rev1.1 anomaly 1.
    NRF_ADC->TASKS_STOP = 1;
}

void readBattery() {
    // Interrupt ADC
    NRF_ADC->INTENSET = (ADC_INTENSET_END_Disabled << ADC_INTENSET_END_Pos);         /*!< Interrupt enabled. */
          
    // Config ADC
    NRF_ADC->CONFIG  = (ADC_CONFIG_EXTREFSEL_None << ADC_CONFIG_EXTREFSEL_Pos)       /* Bits 17..16 : ADC external reference pin selection. */
                    | (ADC_CONFIG_PSEL_AnalogInput3 << ADC_CONFIG_PSEL_Pos)          /*!< Use analog input 0 as analog input. */
                    | (ADC_CONFIG_REFSEL_VBG << ADC_CONFIG_REFSEL_Pos)               /*!< Use internal 1.2V bandgap voltage as reference for conversion. */
                    | (ADC_CONFIG_INPSEL_AnalogInputOneThirdPrescaling << ADC_CONFIG_INPSEL_Pos) /*!< Analog input specified by PSEL with no prescaling used as input for the conversion. */
                    | (ADC_CONFIG_RES_8bit << ADC_CONFIG_RES_Pos);                   /*!< 10bit ADC resolution. */ 
  
    // Enable ADC    
    NRF_ADC->ENABLE = ADC_ENABLE_ENABLE_Enabled;                                     /* Bit 0 : ADC enable. */    
  
    // Start ADC conversion
    NRF_ADC->TASKS_START = 1;
  
    // Wait for conversion to end
    while( !NRF_ADC->EVENTS_END ) {}
    NRF_ADC->EVENTS_END  = 0;
  
    // Save your ADC result
    adc_result2 = NRF_ADC->RESULT;  
    
    // Use the STOP task to save current. Workaround for PAN_028 rev1.1 anomaly 1.
    NRF_ADC->TASKS_STOP = 1;
}

void readSensors() {
    readSensor();

    // Get the highest value and store it as val_in
    val_in = adc_result >> 2;
    if( val_in > max_val_in ) {
        val_in = max_val_in;
    }
    
    if( val_in > 0) {
        // Set a flag to have the PWM updated in main
        new_adc_sample_ready = 1;
    }
}

/**
 * Neopixel Functions
 */
void neopix_set_color_and_show( uint8_t r, uint8_t g, uint8_t b ) {
    uint8_t error;
        error = neopixel_set_color_and_show( &m_strip, 0, r, g, b );
    
        if( error ) {
            //led_to_enable was not within number leds_per_strip
            // Turn off the LED
            nrf_gpio_pin_write( PIN_LEDPWR, 0 );
            //clear and remove strip
            neopixel_clear( &m_strip );
            neopixel_destroy( &m_strip );
        } else {
            // Turn on the LED
            nrf_gpio_pin_write( PIN_LEDPWR, 1 );
        }
        error = neopixel_set_color_and_show( &m_strip, 1, r, g, b );
    
        if( error ) {
            //led_to_enable was not within number leds_per_strip
            // Turn off the LED
            nrf_gpio_pin_write( PIN_LEDPWR, 0 );
            //clear and remove strip
            neopixel_clear( &m_strip );
            neopixel_destroy( &m_strip );
        } else {
            // Turn on the LED
            nrf_gpio_pin_write( PIN_LEDPWR, 1 );
        }
}

void led_fade(uint8_t red_from, uint8_t green_from, uint8_t blue_from, uint8_t red_to, uint8_t green_to, uint8_t blue_to) {
    for(uint8_t i = 0; i <= 100; i+=4) {
        neopix_set_color_and_show(
            getColor(red_from, red_to, i),
            getColor(green_from, green_to, i),
            getColor(blue_from, blue_to, i)
        );
        nrf_delay_ms(constrain(i, 30, 70));
    }
}

void led_fadein(uint8_t red, uint8_t green, uint8_t blue) {
    // Update LED
    nrf_gpio_pin_write( PIN_LEDPWR, 1 );
    neopix_set_color_and_show( 0, 0, 0 );
    
    // Let the LED glow on startup
    led_fade(0, 0, 0, red, green, blue);
}

void led_fadeout(uint8_t red, uint8_t green, uint8_t blue) {
    for(uint8_t o = 100; o >= 1; o-=4) {
        neopix_set_color_and_show(
            getColor(0, red, o),
            getColor(0, green, o),
            getColor(0, blue, o)
        );
        nrf_delay_ms(constrain(o, 30, 70));
    }
    neopix_set_color_and_show( 0, 0, 0 );
    nrf_gpio_pin_write( PIN_LEDPWR, 0 );
}

void led_glow(uint8_t red, uint8_t green, uint8_t blue) {
    led_fadein(red, green, blue);
    led_fadeout(red, green, blue);
}

/**@brief Function for assert macro callback.
 *
 * @details     This function will be called in case of an assert in the SoftDevice.
 *
 * @warning This handler is an example only and does not fit a final product. You need to analyse 
 *          how your product is supposed to react in case of Assert.
 * @warning     On assert from the SoftDevice, the system can only recover on reset.
 *
 * @param[in]   line_num   Line number of the failing ASSERT call.
 * @param[in] p_file_name File name of the failing ASSERT call.
 */
void assert_nrf_callback(uint16_t line_num, const uint8_t * p_file_name)
{
    app_error_handler(DEAD_BEEF, line_num, p_file_name);
}

/**@brief Function for putting the chip into sleep mode.
 *
 * @note This function will not return.
 */
static void sleep_mode_enter(void)
{
    uint32_t err_code;
    if(nrf_gpio_pin_read(PIN_ADAPTER_PRESENT) == 0) {
        if(charging_done == false) {
            led_fadeout(red_battery_empty, green_battery_empty, blue_battery_empty);
        } else {
            led_fadeout(red_battery_charged, green_battery_charged, blue_battery_charged);
        }
    } else {
        led_glow(red_connected, green_connected, blue_connected);
    }
    // Go to system-off mode (this function will not return; wakeup will cause a reset).
    err_code = sd_power_system_off();
    APP_ERROR_CHECK(err_code);
}

/**@brief Function for performing battery measurement and updating the Battery Level characteristic
 *        in Battery Service.
 */
static void battery_level_update(void)
{
    uint32_t err_code;
    uint8_t battery_level = constrain(adc_result2, 0, 29);
    /*
    R1 = 330 kOhm
    R2 = 100 kOhm
    Vout = (Vin * R2) / (R1 + R2)
    Vin = 12.6V -> Vout = 2.930V      // 12.6 -> 2.930
    Vin = 9.6V  -> Vout = 2.234V      // 9.6 -> 2.234
    ADC result range = 0-29
    2.234V-2.930V -> 22-29 (-> 0%-100%)
    */
    //map(x, in_min, in_max, out_min, out_max) =>  (x - in_min) * (out_max - out_min) / (in_max - in_min) + out_min
    uint8_t battery_level_percent = (battery_level - 22) * (100 - 0) / (29 - 22) + 0;
    err_code = ble_bas_battery_level_update(&m_bas, battery_level_percent);
    if ((err_code != NRF_SUCCESS) &&
        (err_code != NRF_ERROR_INVALID_STATE) &&
        (err_code != BLE_ERROR_NO_TX_BUFFERS) &&
        (err_code != BLE_ERROR_GATTS_SYS_ATTR_MISSING)
    )
    {
        APP_ERROR_HANDLER(err_code);
    }
    
    if ( connected == false ) {
        if ( nrf_gpio_pin_read(PIN_ADAPTER_PRESENT) == 0 ) {
            if( nrf_gpio_pin_read(PIN_CHARGE_STATUS) == 0 ) {
                //if((nrf_gpio_pin_read(PIN_CHARGE_DONE) == 1) && (charging_done == false)) {
                if((battery_level_percent < 100) && (charging_done == false)) {
                    // Update LED
                    nrf_gpio_pin_write( PIN_LEDPWR, 1 );
                    neopixel_clear( &m_strip );
                    neopix_set_color_and_show(
                        red_battery_empty,
                        green_battery_empty,
                        blue_battery_empty
                    );
                }
                //if ( (nrf_gpio_pin_read(PIN_CHARGE_DONE) == 0) && (charging_done == false) ) {
                if(battery_level_percent >= 100) {
                    // Update LED
                    nrf_gpio_pin_write( PIN_LEDPWR, 1 );
                    neopixel_clear( &m_strip );
                    neopix_set_color_and_show(
                        red_battery_charged,
                        green_battery_charged,
                        blue_battery_charged
                    );
                    charging_done = true;
                }
            } else {
                neopix_set_color_and_show( 0, 0, 0 );
                neopixel_clear( &m_strip );
                nrf_gpio_pin_write( PIN_LEDPWR, 0 );
            }
        } else {
            //if((nrf_gpio_pin_read(PIN_CHARGE_DONE) == 1) && (battery_level < 100)) {
            charging_done = false;
            if(battery_level_percent < 10) {
                if(attempt == 1) {
                    neopixel_clear( &m_strip );
                    nrf_gpio_pin_write(PIN_LEDPWR, 1);
                    neopix_set_color_and_show(
                        red_battery_empty,
                        green_battery_empty,
                        blue_battery_empty
                    );
                    battery_empty = true;
                    nrf_delay_ms(1000);
                    attempt = 0;
                } else {
                    attempt = 1;
                }
            } else {
                battery_empty = false;
            }
        }
    }
    if(battery_level_percent <= 1) {
        // Go to system-off mode (this function will not return; wakeup will cause a reset).
        sleep_mode_enter();
    }
}

/**@brief Function for handling the Battery measurement timer timeout.
 *
 * @details This function will be called each time the battery level measurement timer expires.
 *
 * @param[in] p_context  Pointer used for passing some arbitrary information (context) from the
 *                       app_start_timer() call to the timeout handler.
 */
static void battery_level_meas_timeout_handler(void * p_context)
{
    UNUSED_PARAMETER(p_context);
    readBattery();
    battery_level_update();
}

/**@brief Function for the Timer initialization.
 *
 * @details Initializes the timer module. This creates and starts application timers.
 */
static void timers_init(void)
{
    uint32_t err_code;

    // Initialize timer module.
    APP_TIMER_INIT(APP_TIMER_PRESCALER, APP_TIMER_MAX_TIMERS, APP_TIMER_OP_QUEUE_SIZE, false);

    // Create timers.
    err_code = app_timer_create(&m_battery_timer_id,
                                APP_TIMER_MODE_REPEATED,
                                battery_level_meas_timeout_handler);
    APP_ERROR_CHECK(err_code);
}

/**@brief   Function for the GAP initialization.
 *
 * @details This function will set up all the necessary GAP (Generic Access Profile) parameters of 
 *          the device. It also sets the permissions and appearance.
 */
static void gap_params_init(void)
{
    uint32_t                err_code;
    ble_gap_conn_params_t   gap_conn_params;
    ble_gap_conn_sec_mode_t sec_mode;

    BLE_GAP_CONN_SEC_MODE_SET_OPEN(&sec_mode);
    
    err_code = sd_ble_gap_device_name_set(&sec_mode,
                                          (const uint8_t *) DEVICE_NAME,
                                          strlen(DEVICE_NAME));
    APP_ERROR_CHECK(err_code);

    err_code = sd_ble_gap_appearance_set(BLE_APPEARANCE_HID_GAMEPAD);
    APP_ERROR_CHECK(err_code);
                                          
    memset(&gap_conn_params, 0, sizeof(gap_conn_params));

    gap_conn_params.min_conn_interval = MIN_CONN_INTERVAL;
    gap_conn_params.max_conn_interval = MAX_CONN_INTERVAL;
    gap_conn_params.slave_latency     = SLAVE_LATENCY;
    gap_conn_params.conn_sup_timeout  = CONN_SUP_TIMEOUT;

    err_code = sd_ble_gap_ppcp_set(&gap_conn_params);
    APP_ERROR_CHECK(err_code);
    
    // Add static passkey:
    uint8_t passkey[] = STATIC_PASSKEY;
    m_static_pin_option.gap_opt.passkey.p_passkey = passkey;
    err_code =  sd_ble_opt_set(BLE_GAP_OPT_PASSKEY, &m_static_pin_option);
    APP_ERROR_CHECK(err_code);
}


/**@brief   Function for the Advertising functionality initialization.
 *
 * @details Encodes the required advertising data and passes it to the stack.
 *          Also builds a structure to be passed to the stack when starting the advertising.
 */
static void advertising_init(void)
{
    uint32_t      err_code;
    ble_advdata_t advdata;
    ble_advdata_t scanrsp;
    
    ble_uuid_t adv_uuids[] =
    {
        {BLE_UUID_NUS_SERVICE, m_nus.uuid_type},
        {BLE_UUID_BATTERY_SERVICE,            BLE_UUID_TYPE_BLE},
        {BLE_UUID_DEVICE_INFORMATION_SERVICE, BLE_UUID_TYPE_BLE}
    };

    // Build and set advertising data.
    memset(&advdata, 0, sizeof(advdata));
    advdata.name_type               = BLE_ADVDATA_FULL_NAME;
    advdata.include_appearance      = true;
    advdata.flags                   = BLE_GAP_ADV_FLAGS_LE_ONLY_LIMITED_DISC_MODE;
    
    memset(&scanrsp, 0, sizeof(scanrsp));
    scanrsp.uuids_complete.uuid_cnt = sizeof(adv_uuids) / sizeof(adv_uuids[0]);
    scanrsp.uuids_complete.p_uuids  = adv_uuids;
    
    err_code = ble_advdata_set(&advdata, &scanrsp);
    APP_ERROR_CHECK(err_code);
}


/**@brief    Function for handling the data from the Nordic UART Service.
 *
 * @details  This function will process the data received from the Nordic UART BLE Service and send
 *           it to the UART module.
 *
 * @param[in] p_nus    Nordic UART Service structure.
 * @param[in] p_data   Data to be send to UART module.
 * @param[in] length   Length of the data.
 */
/**@snippet [Handling the data received over BLE] */
static void nus_data_handler(ble_nus_t * p_nus, uint8_t * p_data, uint16_t length)
{
    uint8_t result = 0;
    for (int i = 0; i < length; i++)
    {
        if((!(p_data[i] < 48)) && (!(p_data[i] > 57))) {
            result = result * 10;
            result = result + (p_data[i] - 48);
        }
    }
    if ((double)result > max_val_in) {
      result = (uint8_t)max_val_in;
    }
  
    // send data to the solenoid & motors.
    if( SOL_ENABLED ) {
        // Map val_in to val_out_sol
        val_out_sol = (uint32_t)( (double)result * ( max_pwm_value / max_val_in ) );
        // Power the solenoid
        nrf_pwm_set_value( 0, val_out_sol );
    }
}

/**@snippet [Handling the data received over BLE] */

/**
 * BLE Radio Notification callback
 */
void ble_on_radio_active_evt(bool radio_active)
{
    if (radio_active == false)
    {
        if ( connected == true ) {
            
            // Update val_in
            readSensors();
            
            // Update LED
            if(battery_empty == false) {
            double transition = ((val_in / max_val_in) * 100);
            neopix_set_color_and_show(
              getColor(red_connected, red_squeeze, transition),
              getColor(green_connected, green_squeeze, transition),
              getColor(blue_connected, blue_squeeze, transition)
            );
            } else {
            neopix_set_color_and_show(
              red_battery_empty,
              green_battery_empty,
              blue_battery_empty
            );
            }
        
            if( val_in <= min_val_in ) {
                val_in = 0;
            }
            
            // Update the PWM when this flag is set
            if( new_adc_sample_ready ) {
                if( val_in != prev_val_in ) {
                    static uint8_t r[BLE_NUS_MAX_DATA_LEN];
                    static uint16_t l = 0;
                    r[0] = (uint8_t)val_in + 48;
                    r[1] = '\n';
                    l = 1;
                    if( val_in > 9 ) {
                        r[0] = ((uint8_t)floor((double)val_in / 10.0) + 48);
                        r[1] = (uint8_t)((val_in - ((r[0] - 48) * 10)) + 48);
                        r[2] = '\n';
                        l = 2;
                    }
                    if( val_in > 99) {
                        r[0] = ((uint8_t)floor((double)val_in / 100.0) + 48);
                        r[1] = ((uint8_t)floor(((double)val_in - (((double)r[0] - 48.0) * 100.0)) / 10.0) + 48);
                        r[2] = (uint8_t)((val_in - ((r[0] - 48) * 100) - ((r[1] - 48) * 10)) + 48);
                        r[3] = '\n';
                        l = 3;
                    }
                
                    uint32_t err_code2;
                    err_code2 = ble_nus_string_send(&m_nus, r, l);
                    if (err_code2 != NRF_ERROR_INVALID_STATE)
                    {
                        APP_ERROR_CHECK(err_code2);
                      
                        prev_val_in = val_in;
                      
                        // Reset the flag
                        new_adc_sample_ready = 0;
                    }
                }
            } else {
                if( prev_val_in != val_in ) { 
                    static uint8_t r[BLE_NUS_MAX_DATA_LEN];
                    static uint16_t l = 0;
                    r[0] = (uint8_t)val_in + 48;
                    r[1] = '\n';
                    l = 1;
                    uint32_t err_code2;
                    err_code2 = ble_nus_string_send(&m_nus, r, l);
                    if (err_code2 != NRF_ERROR_INVALID_STATE)
                    {
                        APP_ERROR_CHECK(err_code2);
                        // Reset the flag
                        prev_val_in = 0;
                        val_in = 0;
                    }
                }
            }
        } else {
            if( prev_val_in != 0 ) {
                static uint8_t r[BLE_NUS_MAX_DATA_LEN];
                static uint16_t l = 0;
                r[0] = (uint8_t)val_in + 48;
                r[1] = '\n';
                l = 1;
                uint32_t err_code2;
                err_code2 = ble_nus_string_send(&m_nus, r, l);
                if (err_code2 != NRF_ERROR_INVALID_STATE)
                {
                    APP_ERROR_CHECK(err_code2);
                    // Reset the flag
                    prev_val_in = 0;
                    val_in = 0;
                }
            }
            nrf_pwm_set_value( 0, 0 );
            //if ( (nrf_gpio_pin_read(PIN_CHARGE_DONE) == 0) && (nrf_gpio_pin_read(PIN_ADAPTER_PRESENT) == 1) ){
            if ( nrf_gpio_pin_read(PIN_ADAPTER_PRESENT) == 1 ){
                nrf_gpio_pin_write( PIN_LEDPWR, 0 );
                neopix_set_color_and_show( 0, 0, 0 );
            }
        }
    }
}

#ifdef BLE_DFU_APP_SUPPORT
/**@brief Function for stopping advertising.
 */
static void advertising_stop(void)
{
    uint32_t err_code;

    err_code = sd_ble_gap_adv_stop();
    APP_ERROR_CHECK(err_code);
}

/**@brief Function for loading application-specific context after establishing a secure connection.
 *
 * @details This function will load the application context and check if the ATT table is marked as 
 *          changed. If the ATT table is marked as changed, a Service Changed Indication
 *          is sent to the peer if the Service Changed CCCD is set to indicate.
 *
 * @param[in] p_handle The Device Manager handle that identifies the connection for which the context 
 *                     should be loaded.
 */
static void app_context_load(dm_handle_t const * p_handle)
{
    uint32_t                 err_code;
    static uint32_t          context_data;
    dm_application_context_t context;

    context.len    = sizeof(context_data);
    context.p_data = (uint8_t *)&context_data;

    err_code = dm_application_context_get(p_handle, &context);
    if (err_code == NRF_SUCCESS)
    {
        // Send Service Changed Indication if ATT table has changed.
        if ((context_data & (DFU_APP_ATT_TABLE_CHANGED << DFU_APP_ATT_TABLE_POS)) != 0)
        {
            err_code = sd_ble_gatts_service_changed(m_conn_handle, APP_SERVICE_HANDLE_START, BLE_HANDLE_MAX);
            if ((err_code != NRF_SUCCESS) &&
                (err_code != BLE_ERROR_INVALID_CONN_HANDLE) &&
                (err_code != NRF_ERROR_INVALID_STATE) &&
                (err_code != BLE_ERROR_NO_TX_BUFFERS) &&
                (err_code != NRF_ERROR_BUSY) &&
                (err_code != BLE_ERROR_GATTS_SYS_ATTR_MISSING))
            {
                APP_ERROR_HANDLER(err_code);
            }
        }

        err_code = dm_application_context_delete(p_handle);
        APP_ERROR_CHECK(err_code);
    }
    else if (err_code == DM_NO_APP_CONTEXT)
    {
        // No context available. Ignore.
    }
    else
    {
        APP_ERROR_HANDLER(err_code);
    }
}

/**@brief Function for preparing for system reset.
 *
 * @details This function implements @ref dfu_app_reset_prepare_t. It will be called by 
 *          @ref dfu_app_handler.c before entering the bootloader/DFU.
 *          This allows the current running application to shut down gracefully.
 */
static void reset_prepare(void)
{
    uint32_t err_code;
    if (m_conn_handle != BLE_CONN_HANDLE_INVALID)
    {
        // Disconnect from peer.
        err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_REMOTE_USER_TERMINATED_CONNECTION);
        APP_ERROR_CHECK(err_code);
    }
    else
    {
        // If not connected, the device will be advertising. Hence stop the advertising.
        advertising_stop();
    }
    err_code = ble_conn_params_stop();
    APP_ERROR_CHECK(err_code);
    led_glow(red_dfu, green_dfu, blue_dfu);
    nrf_delay_ms(500);
}
#endif // BLE_DFU_APP_SUPPORT

/**@brief Function for initializing services that will be used by the application.
 */
static void services_init(void)
{
    uint32_t           err_code;
    ble_nus_init_t     nus_init;
    ble_bas_init_t     bas_init;
    ble_dis_init_t    dis_init;
    
    // Initialize NUS Service.
    memset(&nus_init, 0, sizeof(nus_init));

    nus_init.data_handler = nus_data_handler;
    
    err_code = ble_nus_init(&m_nus, &nus_init);
    APP_ERROR_CHECK(err_code);

    // Initialize Battery Service.
    memset(&bas_init, 0, sizeof(bas_init));

    // Here the sec level for the Battery Service can be changed/increased.
    BLE_GAP_CONN_SEC_MODE_SET_ENC_NO_MITM(&bas_init.battery_level_char_attr_md.cccd_write_perm);
    BLE_GAP_CONN_SEC_MODE_SET_ENC_NO_MITM(&bas_init.battery_level_char_attr_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_NO_ACCESS(&bas_init.battery_level_char_attr_md.write_perm);

    BLE_GAP_CONN_SEC_MODE_SET_ENC_NO_MITM(&bas_init.battery_level_report_read_perm);

    bas_init.evt_handler          = NULL;
    bas_init.support_notification = true;
    bas_init.p_report_ref         = NULL;
    bas_init.initial_batt_level   = 0;

    err_code = ble_bas_init(&m_bas, &bas_init);
    APP_ERROR_CHECK(err_code);
  
    // Initialize Device Information Service.
    memset(&dis_init, 0, sizeof(dis_init));

    ble_srv_ascii_to_utf8(&dis_init.manufact_name_str, (char *)MANUFACTURER_NAME);
    ble_srv_ascii_to_utf8(&dis_init.model_num_str, (char *)MODEL_NUMBER);
    ble_srv_ascii_to_utf8(&dis_init.serial_num_str, (char *)SERIAL_NUMBER);
    ble_srv_ascii_to_utf8(&dis_init.hw_rev_str, (char *)HARDWARE_REVISION);
    ble_srv_ascii_to_utf8(&dis_init.fw_rev_str, (char *)FIRMWARE_REVISION);
    ble_srv_ascii_to_utf8(&dis_init.sw_rev_str, (char *)SOFTWARE_REVISION);

    BLE_GAP_CONN_SEC_MODE_SET_ENC_NO_MITM(&dis_init.dis_attr_md.read_perm);
    BLE_GAP_CONN_SEC_MODE_SET_NO_ACCESS(&dis_init.dis_attr_md.write_perm);

    err_code = ble_dis_init(&dis_init);
    APP_ERROR_CHECK(err_code);
    
#ifdef BLE_DFU_APP_SUPPORT
    ble_dfu_init_t dfus_init;

    // Initialize the Device Firmware Update Service.
    memset(&dfus_init, 0, sizeof(dfus_init));

    dfus_init.evt_handler   = dfu_app_on_dfu_evt;
    dfus_init.error_handler = NULL;
    dfus_init.evt_handler   = dfu_app_on_dfu_evt;
    dfus_init.revision      = DFU_REVISION;

    err_code = ble_dfu_init(&m_dfus, &dfus_init);
    APP_ERROR_CHECK(err_code);

    dfu_app_reset_prepare_set(reset_prepare);
    dfu_app_dm_appl_instance_set(m_app_handle);
#endif // BLE_DFU_APP_SUPPORT
}

/**@brief Function for initializing security parameters.
 */
static void sec_params_init(void)
{
    m_sec_params.bond         = SEC_PARAM_BOND;
    m_sec_params.mitm         = SEC_PARAM_MITM;
    m_sec_params.io_caps      = SEC_PARAM_IO_CAPABILITIES;
    m_sec_params.oob          = SEC_PARAM_OOB;  
    m_sec_params.min_key_size = SEC_PARAM_MIN_KEY_SIZE;
    m_sec_params.max_key_size = SEC_PARAM_MAX_KEY_SIZE;
}

/**@brief Function for starting application timers.
 */
static void application_timers_start(void)
{
    uint32_t err_code;

    // Start application timers.
    err_code = app_timer_start(m_battery_timer_id, BATTERY_LEVEL_MEAS_INTERVAL, NULL);
    APP_ERROR_CHECK(err_code);
}

/**@brief       Function for handling an event from the Connection Parameters Module.
 *
 * @details     This function will be called for all events in the Connection Parameters Module
 *              which are passed to the application.
 *
 * @note        All this function does is to disconnect. This could have been done by simply setting
 *              the disconnect_on_fail config parameter, but instead we use the event handler
 *              mechanism to demonstrate its use.
 *
 * @param[in]   p_evt   Event received from the Connection Parameters Module.
 */
static void on_conn_params_evt(ble_conn_params_evt_t * p_evt)
{
    uint32_t err_code;
    
    if(p_evt->evt_type == BLE_CONN_PARAMS_EVT_FAILED)
    {
        err_code = sd_ble_gap_disconnect(m_conn_handle, BLE_HCI_CONN_INTERVAL_UNACCEPTABLE);
        APP_ERROR_CHECK(err_code);
    }
}


/**@brief       Function for handling errors from the Connection Parameters module.
 *
 * @param[in]   nrf_error   Error code containing information about what went wrong.
 */
static void conn_params_error_handler(uint32_t nrf_error)
{
    APP_ERROR_HANDLER(nrf_error);
}


/**@brief Function for initializing the Connection Parameters module.
 */
static void conn_params_init(void)
{
    uint32_t               err_code;
    ble_conn_params_init_t cp_init;
    
    memset(&cp_init, 0, sizeof(cp_init));

    cp_init.p_conn_params                  = NULL;
    cp_init.first_conn_params_update_delay = FIRST_CONN_PARAMS_UPDATE_DELAY;
    cp_init.next_conn_params_update_delay  = NEXT_CONN_PARAMS_UPDATE_DELAY;
    cp_init.max_conn_params_update_count   = MAX_CONN_PARAMS_UPDATE_COUNT;
    cp_init.start_on_notify_cccd_handle    = BLE_GATT_HANDLE_INVALID;
    cp_init.disconnect_on_fail             = false;
    cp_init.evt_handler                    = on_conn_params_evt;
    cp_init.error_handler                  = conn_params_error_handler;
    
    err_code = ble_conn_params_init(&cp_init);
    APP_ERROR_CHECK(err_code);
}


/**@brief Function for starting advertising.
 */
static void advertising_start(void)
{
    uint32_t             err_code;
    ble_gap_adv_params_t adv_params;
    
    // Start advertising.
    memset(&adv_params, 0, sizeof(adv_params));
    
    adv_params.type        = BLE_GAP_ADV_TYPE_ADV_IND;
    adv_params.p_peer_addr = NULL;
    adv_params.fp          = BLE_GAP_ADV_FP_ANY;
    adv_params.interval    = APP_ADV_INTERVAL;
    adv_params.timeout     = APP_ADV_TIMEOUT_IN_SECONDS;

    err_code = sd_ble_gap_adv_start(&adv_params);
    APP_ERROR_CHECK(err_code);
}

/**@brief       Function for the Application's S110 SoftDevice event handler.
 *
 * @param[in]   p_ble_evt   S110 SoftDevice event.
 */
static void on_ble_evt(ble_evt_t * p_ble_evt)
{
    uint32_t                         err_code;
    static ble_gap_sec_keyset_t      s_sec_keyset;
    ble_gap_enc_info_t *             p_enc_info;
    
    switch (p_ble_evt->header.evt_id)
    {
        case BLE_GAP_EVT_CONNECTED:
            m_conn_handle = p_ble_evt->evt.gap_evt.conn_handle;
            connected = true;
            //if(nrf_gpio_pin_read(PIN_ADAPTER_PRESENT) == 0) {
            //    if(charging_done == false) {
            //        led_fade(red_battery_empty, green_battery_empty, blue_battery_empty, red_connected, green_connected, blue_connected);
            //    } else {
            //        led_fade(red_battery_charged, green_battery_charged, blue_battery_charged, red_connected, green_connected, blue_connected);
            //    }
            //} else {
            //    led_fadein(red_connected, green_connected, blue_connected);
            //}
            break;
            
        case BLE_GAP_EVT_DISCONNECTED:
            m_conn_handle = BLE_CONN_HANDLE_INVALID;
            connected = false;
            //if(nrf_gpio_pin_read(PIN_ADAPTER_PRESENT) == 0) {
            //    if(charging_done == false) {
            //        led_fade(red_connected, green_connected, blue_connected, red_battery_empty, green_battery_empty, blue_battery_empty);
            //    } else {
            //        led_fade(red_connected, green_connected, blue_connected, red_battery_charged, green_battery_charged, blue_battery_charged);
            //    }
            //} else {
            //    led_fadeout(red_connected, green_connected, blue_connected);
            //}
            advertising_start();
            break;
            
        case BLE_GAP_EVT_SEC_PARAMS_REQUEST:
            s_sec_keyset.keys_periph.p_enc_key = NULL;
            err_code = sd_ble_gap_sec_params_reply(m_conn_handle, 
                                                   BLE_GAP_SEC_STATUS_SUCCESS, 
                                                   &m_sec_params,
                                                   &s_sec_keyset);
            APP_ERROR_CHECK(err_code);
            break;
            
        case BLE_GATTS_EVT_SYS_ATTR_MISSING:
            err_code = sd_ble_gatts_sys_attr_set(m_conn_handle, NULL, 0, 0);
            APP_ERROR_CHECK(err_code);
            break;

        case BLE_GAP_EVT_AUTH_STATUS:
            // TODO: Adoptation to s110v8.0.0, is this needed anymore ?
            break;
            
        case BLE_GAP_EVT_SEC_INFO_REQUEST:
            if (s_sec_keyset.keys_periph.p_enc_key != NULL)
            {
                p_enc_info = &s_sec_keyset.keys_periph.p_enc_key->enc_info;
                err_code = sd_ble_gap_sec_info_reply(m_conn_handle, p_enc_info, NULL, NULL);
                APP_ERROR_CHECK(err_code);
            }
            else
            {
                // No keys found for this device.
                err_code = sd_ble_gap_sec_info_reply(m_conn_handle, NULL, NULL, NULL);
                APP_ERROR_CHECK(err_code);
            }
            break;

        case BLE_GAP_EVT_TIMEOUT:
            if (p_ble_evt->evt.gap_evt.params.timeout.src == BLE_GAP_TIMEOUT_SRC_ADVERTISING)
            {
                connected = false;
                //if(nrf_gpio_pin_read(PIN_ADAPTER_PRESENT) == 0) {
                //    advertising_start(); // endlessloop
                    //advertising_stop();
                //} else {
                    sleep_mode_enter();
                //}
            }
            break;

        default:
            // No implementation needed.
            break;
    }
}


/**@brief Function for dispatching a S110 SoftDevice event to all modules with a S110 SoftDevice 
 *        event handler.
 *
 * @details This function is called from the S110 SoftDevice event interrupt handler after a S110 
 *          SoftDevice event has been received.
 *
 * @param[in]   p_ble_evt   S110 SoftDevice event.
 */
static void ble_evt_dispatch(ble_evt_t * p_ble_evt)
{
    ble_conn_params_on_ble_evt(p_ble_evt);
    ble_nus_on_ble_evt(&m_nus, p_ble_evt);
    ble_bas_on_ble_evt(&m_bas, p_ble_evt);
#ifdef BLE_DFU_APP_SUPPORT
    ble_dfu_on_ble_evt(&m_dfus, p_ble_evt);
#endif // BLE_DFU_APP_SUPPORT
    on_ble_evt(p_ble_evt);
}

/**@brief Function for dispatching a system event to interested modules.
 *
 * @details This function is called from the System event interrupt handler after a system
 *          event has been received.
 *
 * @param[in] sys_evt  System stack event.
 */
static void sys_evt_dispatch(uint32_t sys_evt)
{
    pstorage_sys_event_handler(sys_evt);
    ble_advertising_on_sys_evt(sys_evt);
}

/**@brief   Function for the S110 SoftDevice initialization.
 *
 * @details This function initializes the S110 SoftDevice and the BLE event interrupt.
 */
static void ble_stack_init(void)
{
    uint32_t err_code;
    
    // Initialize SoftDevice.
    SOFTDEVICE_HANDLER_INIT(NRF_CLOCK_LFCLKSRC_XTAL_20_PPM, NULL);

    // Enable BLE stack.
    ble_enable_params_t ble_enable_params;
    memset(&ble_enable_params, 0, sizeof(ble_enable_params));
    ble_enable_params.gatts_enable_params.service_changed = IS_SRVC_CHANGED_CHARACT_PRESENT;
    err_code = sd_ble_enable(&ble_enable_params);
    APP_ERROR_CHECK(err_code);
    
    // Subscribe for BLE events.
    err_code = softdevice_ble_evt_handler_set(ble_evt_dispatch);
    APP_ERROR_CHECK(err_code);
  
  // Register with the SoftDevice handler module for BLE events.
    err_code = softdevice_sys_evt_handler_set(sys_evt_dispatch);
    APP_ERROR_CHECK(err_code);
}

/**@brief Function for handling the Device Manager events.
 *
 * @param[in] p_evt  Data associated to the device manager event.
 */
static uint32_t device_manager_evt_handler(dm_handle_t const * p_handle,
                                           dm_event_t const  * p_event,
                                           ret_code_t        event_result)
{
    APP_ERROR_CHECK(event_result);

#ifdef BLE_DFU_APP_SUPPORT
    if (p_event->event_id == DM_EVT_LINK_SECURED)
    {
        app_context_load(p_handle);
    }
#endif // BLE_DFU_APP_SUPPORT

    return NRF_SUCCESS;
}

/**@brief Function for the Device Manager initialization.
 */
static void device_manager_init(void)
{
    uint32_t               err_code;
    dm_init_param_t        init_data;
    dm_application_param_t register_param;

    // Initialize persistent storage module.
    err_code = pstorage_init();
    APP_ERROR_CHECK(err_code);

    err_code = dm_init(&init_data);
    APP_ERROR_CHECK(err_code);

    memset(&register_param.sec_param, 0, sizeof(ble_gap_sec_params_t));

    register_param.sec_param.bond         = SEC_PARAM_BOND;
    register_param.sec_param.mitm         = SEC_PARAM_MITM;
    register_param.sec_param.io_caps      = SEC_PARAM_IO_CAPABILITIES;
    register_param.sec_param.oob          = SEC_PARAM_OOB;
    register_param.sec_param.min_key_size = SEC_PARAM_MIN_KEY_SIZE;
    register_param.sec_param.max_key_size = SEC_PARAM_MAX_KEY_SIZE;
    register_param.evt_handler            = device_manager_evt_handler;
    register_param.service_type           = DM_PROTOCOL_CNTXT_GATT_SRVR_ID;

    err_code = dm_register(&m_app_handle, &register_param);
    APP_ERROR_CHECK(err_code);
}

/**@brief  Function for configuring the buttons.
 */
static void buttons_init(void)
{
    /**< Buttons used to wake up the application. */
    nrf_gpio_cfg_sense_input(PIN_SEN,
                             NRF_GPIO_PIN_PULLDOWN,
                             NRF_GPIO_PIN_SENSE_HIGH);
    
    if ( nrf_gpio_pin_read(PIN_ADAPTER_PRESENT) == 0 ) {
        nrf_gpio_cfg_sense_input(PIN_ADAPTER_PRESENT,
                                NRF_GPIO_PIN_PULLUP, 
                                NRF_GPIO_PIN_SENSE_HIGH);
    } else {
        nrf_gpio_cfg_sense_input(PIN_ADAPTER_PRESENT,
                                NRF_GPIO_PIN_PULLUP, 
                                NRF_GPIO_PIN_SENSE_LOW);
    }
    nrf_gpio_cfg_sense_input(PIN_CHARGE_DONE,
                             NRF_GPIO_PIN_PULLDOWN,
                             NRF_GPIO_PIN_SENSE_HIGH);
}

/**@brief  Function for placing the application in low power state while waiting for events.
 */
static void power_manage(void)
{
    uint32_t err_code = sd_app_evt_wait();
    APP_ERROR_CHECK(err_code);
}

void gpio_init() {
    // Configure input pins
    nrf_gpio_cfg_input( PIN_VBAT_ADC, NRF_GPIO_PIN_PULLDOWN );
    nrf_gpio_cfg_input( PIN_SEN, NRF_GPIO_PIN_PULLDOWN );
    // p0.12-0.14 require internal pullup!
    nrf_gpio_cfg_input( PIN_CHARGE_STATUS, NRF_GPIO_PIN_PULLUP );
    nrf_gpio_cfg_input( PIN_CHARGE_DONE, NRF_GPIO_PIN_PULLUP );
    nrf_gpio_cfg_input( PIN_ADAPTER_PRESENT, NRF_GPIO_PIN_PULLUP );
  
    // Configure output pins
    nrf_gpio_cfg_output( PIN_SOL );
    nrf_gpio_cfg_output( PIN_LEDPWR );
    nrf_gpio_cfg_output( PIN_MOSILED );
    nrf_gpio_pin_clear( PIN_SOL );
    nrf_gpio_pin_clear( PIN_LEDPWR );
    nrf_gpio_pin_clear( PIN_MOSILED );
}

void pwm_init() {
    nrf_pwm_config_t pwm_config = PWM_DEFAULT_CONFIG;
    
    pwm_config.mode             = PWM_CONFIG;
    pwm_config.num_channels     = 3;
    pwm_config.gpio_num[0]      = PIN_SOL;
    
    // Initialize the PWM library
    nrf_pwm_init( &pwm_config );
  
    max_pwm_value = nrf_pwm_get_max_value();
}

void neopix_init() {
    neopixel_init( &m_strip, PIN_MOSILED, leds_per_strip );
    neopixel_clear( &m_strip );
  
    //if(nrf_gpio_pin_read(PIN_ADAPTER_PRESENT) == 0) {
    //    if(charging_done == false) {
    //        led_fadein(red_connected, green_connected, blue_connected);
    //        led_fade(red_connected, green_connected, blue_connected, red_battery_empty, green_battery_empty, blue_battery_empty);
    //    } else {
    //        led_fadein(red_connected, green_connected, blue_connected);
    //        led_fade(red_connected, green_connected, blue_connected, red_battery_charged, green_battery_charged, blue_battery_charged);
    //    }
    //} else {
        led_glow(red_connected, green_connected, blue_connected);
    //}
}

/**@brief Function for enabling radio notyfication.
 */
static void radio_notification_init(void)
{
        uint32_t err_code;

        // Enable Radio Notification
        err_code = ble_radio_notification_init(NRF_APP_PRIORITY_LOW,
                                                NRF_RADIO_NOTIFICATION_DISTANCE_800US,
                                                ble_on_radio_active_evt);
        APP_ERROR_CHECK(err_code);      
}

/**@brief  Application main function.
 */
int main(void)
{
    // Initialize.
    APP_GPIOTE_INIT(APP_GPIOTE_MAX_USERS);
    ble_stack_init();
    
    timers_init();
  
    device_manager_init();
  
    gap_params_init();
    services_init();
    advertising_init();
    conn_params_init();
    sec_params_init();
    
    // Initialize gpio
    gpio_init();
    buttons_init();
    // Initialize PWM Library
    pwm_init();
    // Initialize Neopixel Library
    neopix_init();
    
    radio_notification_init();
    
    // Start execution.
    application_timers_start();
    advertising_start();
    
    // Enter main loop.
    for (;;)
    {
        power_manage();
    }
}


/** 
 * @}
 */
