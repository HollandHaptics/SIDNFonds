
/*
 * Auto generated Run-Time-Environment Component Configuration File
 *      *** Do not modify ! ***
 *
 * Project: 'frebble_3.0.0' 
 * Target:  'frebble_3.0.0' 
 */

#ifndef RTE_COMPONENTS_H
#define RTE_COMPONENTS_H

#define S110
#define SOFTDEVICE_PRESENT

#endif /* RTE_COMPONENTS_H */
